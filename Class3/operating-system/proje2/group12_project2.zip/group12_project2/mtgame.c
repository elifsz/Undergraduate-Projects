#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

int number_of_rock = 0;
int number_of_scissor = 0;
int number_of_paper = 0;



int thread1_score = 0;
int thread2_score = 0;
int thread3_score = 0;
char thread1;
char thread2;
char thread3;
int turn = 0;
char game[3] = {'R', 'P', 'S'};

pthread_mutex_t mutex1;
pthread_mutex_t mutex2;
pthread_mutex_t mutex3;
void *thread_random()
{
    while (1)
    {
        pthread_mutex_lock(&mutex1);
        if (thread1_score == 5)
        {
            printf("1.Thread has won the game with score: Score: %d – %d – %d in %d Turns.\n", thread1_score, thread2_score, thread3_score, turn);
        }
        else if (thread2_score == 5)
        {
            printf("2.Thread has won the game with score: Score: %d – %d – %d in %d Turns.\n", thread1_score, thread2_score, thread3_score, turn);
        }
        else if (thread3_score == 5)
        {
            printf("3.Thread has won the game with score: Score: %d – %d – %d in %d Turns.\n", thread1_score, thread2_score, thread3_score, turn);
        }
        if (thread1_score == 5 || thread2_score == 5 || thread3_score == 5)
        {
            sleep(1);
            printf("--\nhow many times items were selected: SCISSORS: %d ,  PAPER: %d , ROCK: %d \n--\n--",number_of_scissor, number_of_paper,number_of_rock);
            printf("\n1.Thread terminated\n");
            pthread_exit(NULL);
            break;
        }
        srand(time(NULL));
        int thread_random = rand() % 3;

        thread1 = game[thread_random];

        sleep(1);
        if (thread1 == 'R')
            number_of_rock++;
        else if (thread1 == 'P')
            number_of_paper++;
        else if (thread1 == 'S')
            number_of_scissor++;
        turn++;
        printf("%d. Turn ,", turn);
        if (thread1 == 'P')
        {
            printf("1.Thread PAPER ");
            if (thread2 == 'P')
            {
                printf("2.Thread PAPER ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    printf("Draw Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    printf("Draw Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    thread3_score++;
                    printf("3.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
            else if (thread2 == 'R')
            {
              
                printf("2.Thread ROCK ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    printf("Draw: Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    thread1_score++;
                    printf("1.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
            else if (thread2 == 'S')
            {
                printf("2.Thread SCISSOR ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    thread2_score++;
                    printf("2.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
        }
        else if (thread1 == 'S')
        {
            printf("1.Thread SCISSOR ");
            if (thread2 == 'P')
            {
                printf("2.Thread PAPER ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    thread1_score++;
                    printf("1.Thread Win Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
            else if (thread2 == 'R')
            {
                
                printf("2.Thread ROCK ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                   
                    printf("3.Thread ROCK\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    thread2_score++;
                    printf("2.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
            else if (thread2 == 'S')
            {
                printf("2.Thread SCISSOR ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    thread3_score++;
                    printf("3.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
        }
        else if (thread1 == 'R')
        {
            
            printf("1.Thread ROCK ");
            if (thread2 == 'P')
            {
                printf("2.Thread PAPER ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    thread2_score++;
                    printf("2.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
            else if (thread2 == 'R')
            {
                
                printf("2.Thread ROCK ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    thread3_score++;
                    printf("3.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                    
                    printf("3.Thread ROCK\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
            else if (thread2 == 'S')
            {
                printf("2.Thread SCISSOR ");
                if (thread3 == 'P')
                {
                    printf("3.Thread PAPER\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'R')
                {
                   
                    printf("3.Thread ROCK\n");
                    printf("Draw, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
                else if (thread3 == 'S')
                {
                    printf("3.Thread SCISSOR\n");
                    thread1_score++;
                    printf("1.Thread Win, Score: %d - %d - %d\n", thread1_score, thread2_score, thread3_score);
                    printf("--\n--\n");
                }
            }
        }

        pthread_mutex_unlock(&mutex1);
    }
}
void *thread2_random()
{
    while (1)
    {
        pthread_mutex_lock(&mutex2);
        if (thread1_score == 5 || thread2_score == 5 || thread3_score == 5)
        {
            sleep(1);
            printf("2.Thread terminated\n");
            pthread_exit(NULL);
            break;
        }
        sleep(1);
        int thread_random = rand() % 3;
        srand(time(NULL));
        thread2 = game[thread_random];
        if (thread2 == 'R')
            number_of_rock++;
        else if (thread2 == 'P')
            number_of_paper++;
        else if (thread2 == 'S')
            number_of_scissor++;
        
        pthread_mutex_unlock(&mutex2);
    }
}
void *thread3_random()
{
    while (1)
    {
        pthread_mutex_lock(&mutex3);
        if (thread1_score == 5 || thread2_score == 5 || thread3_score == 5)
        {
            sleep(1);
            printf("3.Thread terminated\n");
            pthread_exit(NULL);
            break;
        }
        sleep(1);
        srand(time(NULL));
        int thread_random = rand() % 3;
        thread3 = game[thread_random];
        if (thread3 == 'R')
            number_of_rock++;
        else if (thread3 == 'P')
            number_of_paper++;
        else if (thread3 == 'S')
            number_of_scissor++;
        
        pthread_mutex_unlock(&mutex3);
    }
}

int main(int argc, char *argv[])
{
    srand(time(NULL));

    pthread_t thread_id1;
    pthread_t thread_id2;
    pthread_t thread_id3;
    pthread_mutex_init(&mutex1, NULL);
    pthread_mutex_init(&mutex2, NULL);
    pthread_mutex_init(&mutex3, NULL);
    printf("The game has launched\n3 threads will be created\nThe game starts\n");
    pthread_create(&thread_id1, NULL, &thread_random, NULL);
    pthread_create(&thread_id2, NULL, &thread2_random, NULL);
    pthread_create(&thread_id3, NULL, &thread3_random, NULL);

    pthread_join(thread_id1, NULL);
    pthread_join(thread_id2, NULL);
    pthread_join(thread_id3, NULL);
    printf("\nThreads are joined by main process\n");

    printf("Game finished\n");

    pthread_mutex_destroy(&mutex1);
    pthread_mutex_destroy(&mutex2);
    pthread_mutex_destroy(&mutex3);

} //end main
