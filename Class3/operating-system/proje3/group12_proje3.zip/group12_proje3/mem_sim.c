#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define KB 4
#define MAX 50

int internal_fragmentation = 0;
int rejected_process = 0;
int number_of_external_fragmentation = 0;
int unused = 0;
int calculate_holes_for_worst(int *memory, int fSize, int pSize);
int calculate_holes_for_best(int *memory, int fSize, int pSize);
int calculate_frame(int size)
{
	int frame;
	if (size % 4 != 0)
	{
		frame = size / 4.0 + 1;
	}
	else
	{
		frame = size / 4;
	}
	return frame;
}
int calculate_internal(int size)
{
	if (size % 4 != 0)
	{
		return 4 - size % 4;
	}
	else
	{
		return 0;
	}
}

int firstFitAllocation(int *memory, int fSize, int pId, int pSize, int restFrame)
{

	int restTemp = restFrame;
	int frame = calculate_frame(pSize);
	int starting = 0;
	int is_empty = 0;
	int i = 0, j = 1;
	if (restFrame >= frame)
	{
		internal_fragmentation += calculate_internal(pSize);
		while (i < fSize)
		{
			if (memory[i] != 0)
			{

				if (restTemp - is_empty <= frame)
				{
					printf("\n%c %d %d -> %d frames will be used, ERROR! External fragmentation", 'B', pId, pSize, frame);
					number_of_external_fragmentation += 1;
					break;
				}
				restTemp -= is_empty;
				is_empty = 0;
			}
			else
			{
				is_empty++;
			}

			if (is_empty == frame)
			{
				printf("\n%c %d %d -> %d frames will be used, remaining frame #frames: %d", 'B', pId, pSize, frame, restFrame - frame);
				starting = i - frame;
				restFrame -= frame;

				while (j <= frame)
				{
					memory[starting + j] = pId;
					j++;
				}
				break;
			}
			i++;
		}
	}
	else
	{
		printf("\n%c %d %d -> ERROR! Insufficient memory", 'B', pId, pSize);
		rejected_process += 1;
	}
	return restFrame;
}
int flagBest = 0;
int bestFitAllocation(int *memory, int fSize, int pId, int pSize, int restFrame)
{
	int restTemp = restFrame;

	int frame = calculate_frame(pSize);
	unused += 4 * frame - pSize;
	int starting = 0;
	int is_empty = 0;
	int i = 0, j = 1;
	if (restFrame >= frame)
	{
		internal_fragmentation += calculate_internal(pSize);
		while (i < fSize)
		{
			if (memory[i] != 0)
			{
				if (restTemp - is_empty <= frame)
				{
					printf("\n%c %d %d -> %d frames will be used, ERROR! External fragmentation", 'B', pId, pSize, frame);
					number_of_external_fragmentation += 1;
					break;
				}
				restTemp -= is_empty;
				is_empty = 0;
			}
			else
			{
				is_empty++;
			}

			if (is_empty == frame && !flagBest)
			{
				printf("\n%c %d %d -> %d frames will be used, remaining_frame #frames: %3d", 'B', pId, pSize, frame, restFrame - frame);
				starting = i - frame;
				restFrame -= frame;

				while (j <= frame)
				{
					memory[starting + j] = pId;
					j++;
				}
				break;
			}
			else if (is_empty == frame && flagBest)
			{
				printf("\n%c %d %d -> %d frames will be used, remaining_frame #frames: %3d", 'B', pId, pSize, frame, restFrame - frame);
				starting = calculate_holes_for_best(memory, fSize, pSize);
				restFrame -= frame;

				while (j <= frame)
				{
					memory[starting + j] = pId;
					j++;
				}
				break;
			}
			i++;
		}
	}
	else
	{
		printf("\n%c %d %d -> ERROR! Insufficient memory", 'B', pId, pSize);
		unused -= 4 * frame - pSize;
		rejected_process += 1;
	}
	return restFrame;
}
int flagWorst = 0;
int worstFitAllocation(int *memory, int fSize, int pId, int pSize, int restFrame)
{

	int restTemp = restFrame;

	int frame = calculate_frame(pSize);
	unused += 4 * frame - pSize;
	int starting = 0;
	int is_empty = 0;
	int i = 0, j = 1;
	if (restFrame >= frame)
	{
		internal_fragmentation += calculate_internal(pSize);
		while (i < fSize)
		{
			if (memory[i] == 0)
			{
				is_empty += 1;
			}
			else
			{
				if (restTemp - is_empty <= frame)
				{
					printf("\n%c %d %d -> %d frames will be used, ERROR! External fragmentation", 'B', pId, pSize, frame);
					number_of_external_fragmentation += 1;
					break;
				}
				restTemp -= is_empty;
				is_empty = 0;
			}

			if (is_empty == frame && !flagWorst)
			{
				printf("\n%c %d %d -> %d frames will be used, remaining_frame #frames: %d", 'B', pId, pSize, frame, restFrame - frame);
				starting = i - frame;
				restFrame -= frame;

				while (j <= frame)
				{
					memory[starting + j] = pId;
					j++;
				}
				break;
			}
			else if (is_empty == frame && flagWorst)
			{
				printf("\n%c %d %d -> %d frames will be used, remaining_frame #frames: %d", 'B', pId, pSize, frame, restFrame - frame);
				starting = calculate_holes_for_worst(memory, fSize, pSize);
				restFrame -= frame;

				while (j <= frame)
				{
					memory[starting + j] = pId;
					j++;
				}
				break;
			}
			i++;
		}
	}
	else
	{
		printf("\n%c %d %d ->  ERROR! Insufficient memory", 'B', pId, pSize);
		rejected_process += 1;
		unused -= 4 * frame - pSize;
	}
	return restFrame;
}
int deallocation(int *memory, int fSize, int pId, int restFrame, int operation)
{
	if (operation == 2)
	{
		flagBest = 1;
	}
	else if (operation == 3)
	{
		flagWorst = 1;
	}
	int i = 0;
	int is_empty = 0;

	while (i < fSize)
	{
		if (memory[i] == pId)
		{
			is_empty++;
			memory[i] = 0;
		}
		i++;
	}

	printf("\n%c %d     -> %d frames are deallocated, available #frames: %3d", 'E', pId, is_empty, restFrame + is_empty);

	return is_empty + restFrame;
}
int calculate_holes_for_best(int *memory, int fSize, int pSize)
{
	//first index is start address
	//second index is size
	int hole[MAX][2] = {0};
	int i = 0, count = 0, is_empty = 0;
	for (i = 0; i < fSize; i++)
	{
		if (memory[i] == 0)
		{
			is_empty += 1;
		}
		else
		{
			if (is_empty >= calculate_frame(pSize))
			{
				hole[count][0] = i - is_empty - 1;
				hole[count][1] = is_empty;
				count += 1;
			}
			is_empty = 0;
		}

		if (i == fSize - 1 && is_empty > calculate_frame(pSize))
		{
			hole[count][0] = i - is_empty;
			hole[count][1] = is_empty;
		}
	}

	int j = 0;

	int min = hole[0][1];
	for (j = 0; j < MAX; j++)
	{
		if (hole[j][1] < min && hole[j][1] != 0)
		{
			min = hole[j][1];
		}
	}

	for (j = 0; j < MAX; j++)
	{
		if (hole[j][1] == min)
		{
			return hole[j][0];
		}
	}
	return 0;
}

int calculate_holes_for_worst(int *memory, int fSize, int pSize)
{
	//first index is start address
	//second index is size
	int hole[MAX][2] = {0};
	int i = 0, count = 0, is_empty = 0;
	for (i = 0; i < fSize; i++)
	{
		if (memory[i] == 0)
		{
			is_empty += 1;
		}
		else
		{
			if (is_empty >= calculate_frame(pSize))
			{
				hole[count][0] = i - is_empty - 1;
				hole[count][1] = is_empty;
				count += 1;
			}
			is_empty = 0;
		}

		if (i == fSize - 1 && is_empty > calculate_frame(pSize))
		{
			hole[count][0] = i - is_empty;
			hole[count][1] = is_empty;
		}
	}

	int j = 0;

	int max = hole[0][1];
	for (j = 0; j < MAX; j++)
	{
		if (hole[j][1] > max && hole[j][1] != 0)
		{
			max = hole[j][1];
		}
	}

	for (j = 0; j < MAX; j++)
	{
		if (hole[j][1] == max)
		{
			return hole[j][0];
		}
	}
	return 0;
}
void print_information(int restFrame, int internal_fragmentation, int number_of_external_fragmentation, int rejected_process)
{
	printf("\n\nTotal free memory in holes: %d frames, %d KB", restFrame, restFrame * KB);
	printf("\nTotal memory wasted as an internal fragmentation: %d", internal_fragmentation);
	printf("\nTotal number of rejected processes due to external fragmentation: %d", number_of_external_fragmentation);
	printf("\nTotal number of rejected processes due to insufficient memory: %d", rejected_process);
}
void print_hole(int *memory, int fSize)
{
	printf("\n\nHoles :");
	int i = 0, is_empty = 0;
	while (i < fSize)
	{
		if (memory[i] != 0)
		{
			if (is_empty > 0)
			{
				printf("\n%d %d", i - is_empty, is_empty);
			}
			is_empty = 0;
		}
		else
		{
			is_empty++;
		}

		if (i == fSize - 1 && is_empty > 0)
		{
			printf("\n%d %d", i - is_empty + 1, is_empty);
		}
		i++;
	}
}
void mem_sim(int size_of_memory, char file_name[], int alloc_strategy)
{

	FILE *file = fopen(file_name, "r");

	int total_number_of_frame = size_of_memory / 4;

	//starting all frame empty
	int memory[total_number_of_frame];
	int m;
	for (m = 0; m < total_number_of_frame; m++)
	{
		memory[m] = 0;
	}

	char pType;
	int pId;
	int pSize;
	int restFrame = total_number_of_frame;

	//FIRST-FIT PART
	if (alloc_strategy == 1)
	{
		while (fscanf(file, "%c %d %d ", &pType, &pId, &pSize) != EOF)
		{
			if (pType == 'B')
			{
				restFrame = firstFitAllocation(memory, total_number_of_frame, pId, pSize, restFrame);
			}
			else if (pType == 'E')
			{
				restFrame = deallocation(memory, total_number_of_frame, pId, restFrame, alloc_strategy);
			}
		}
		print_information(restFrame, internal_fragmentation, number_of_external_fragmentation, rejected_process);
		print_hole(memory, total_number_of_frame);
		printf("\n");
	}
	//BEST-FIT PART
	else if (alloc_strategy == 2)
	{
		while (fscanf(file, "%c %d %d ", &pType, &pId, &pSize) != EOF)
		{
			if (pType == 'B')
			{
				restFrame = bestFitAllocation(memory, total_number_of_frame, pId, pSize, restFrame);
			}
			else if (pType == 'E')
			{
				restFrame = deallocation(memory, total_number_of_frame, pId, restFrame, alloc_strategy);
			}
		}
		print_information(restFrame, internal_fragmentation, number_of_external_fragmentation, rejected_process);
		print_hole(memory, total_number_of_frame);
		printf("\n");
	}
	//WORST-FIT PART
	else if (alloc_strategy == 3)
	{
		while (fscanf(file, "%c %d %d ", &pType, &pId, &pSize) != EOF)
		{
			if (pType == 'B')
			{
				restFrame = worstFitAllocation(memory, total_number_of_frame, pId, pSize, restFrame);
			}
			else if (pType == 'E')
			{
				restFrame = deallocation(memory, total_number_of_frame, pId, restFrame, alloc_strategy);
			}
		}
		print_information(restFrame, internal_fragmentation, number_of_external_fragmentation, rejected_process);
		print_hole(memory, total_number_of_frame);
		printf("\n");
	}
	fclose(file);
}

int main()
{
	printf("Program Launched\n");
	int choice;
	printf("Enter the choice (1, 2, 3) : ");
	scanf("%d", &choice);
	if (choice == 1)
	{
		printf("FIRST FIT ALLOCATION\n");
		mem_sim(1024, "processes.txt", choice);
	}
	else if (choice == 2)
	{
		printf("\nBEST FIT ALLOCATION\n");
		mem_sim(1024, "processes.txt", choice);
	}
	else if (choice == 3)
	{
		printf("\nWORST FIT ALLOCATION\n");
		mem_sim(1024, "processes.txt", choice);
	}
}
