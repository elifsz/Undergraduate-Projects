#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
int main(int argc, char *argv[])
{
    int p1[2]; // C -> P
    if (pipe(p1) == -1)
    {
        return 1;
    }
    int parent_score = 0;
    int child_score = 0;
    int i = 0;
    int pid = fork();
    if (pid == -1)
    {
        return 2;
    }
     if (pid == 0)
    {
        printf("The game has launched\n");
        printf("Child process is created\n");
        printf("The game starts\n\n");
    }
    char game[3] = {'R', 'P', 'S'};

    do
    {
        //CHILD PART
        if (pid == 0)
        {
            char child = '\0';
            sleep(1);
            srand(time(NULL));
            int child_random = (rand() % getpid()) % 3;
            int random = rand() % 100;
            child = game[child_random];
            write(p1[1], &child, sizeof(child));
        }
        else
        { //PARENT PART 
            if (child_score == 5 || parent_score == 5)
            {
                if (parent_score == 5)
                {
                    printf("Parent has won the game with score: %d - %d in %d Turns\n", parent_score, child_score, i);
                }
                else
                {
                    printf("Child has won the game with score: %d - %d in %d Turns\n", parent_score, child_score, i);
                }
            close(p1[1]);
            close(p1[0]);
            printf("Child has terminated\n");
            kill(pid, SIGKILL);
            printf("Parent waits child with wait()\n");
            wait(NULL);
            printf("Parent has terminated\n");
            kill(getpid(), SIGKILL);
            } //if end part

            char child;
            read(p1[0], &child, sizeof(child));
            kill(pid,SIGSTOP);
            int parent_random = (rand() % getpid()) % 3;
            char parent = game[parent_random];
            i++;
            printf("Turn %d, ", i);
            if (child != parent)
            {
                if (parent == 'R' && child == 'P')
                {
                    child_score++;
                    printf("Parent : ROCK, Child : PAPER\n");
                    printf("Child win, score %d - %d\n", parent_score, child_score);
                }
                else if (parent == 'R' && child == 'S')
                {
                    parent_score++;
                    printf("Parent : ROCK, Child : SCISSOR\n");
                    printf("Parent win, score %d - %d\n", parent_score, child_score);
                }
                else if (parent == 'P' && child == 'R')
                {
                    parent_score++;
                    printf("Parent : PAPER, Child : ROCK\n");
                    printf("Parent win, score %d - %d\n", parent_score, child_score);
                }
                else if (parent == 'P' && child == 'S')
                {
                    child_score++;
                    printf("Parent : PAPER, Child : SCISSOR\n");
                    printf("Child win, score %d - %d\n", parent_score, child_score);
                }
                else if (parent == 'S' && child == 'P')
                {
                    parent_score++;
                    printf("Parent : SCISSOR, Child : PAPER\n");
                    printf("Parent win, score %d - %d\n", parent_score, child_score);
                }
                else if (parent == 'S' && child == 'R')
                {
                    child_score++;
                    printf("Parent : SCISSOR, Child : ROCK\n");
                    printf("Child win, score %d - %d\n", parent_score, child_score);
                }
            } //end game if
            else
            {
                if (parent == 'S' && child == 'S')
                {
                    printf("Parent : SCISSOR, Child : SCISSOR\n");
                    printf("Draw, Score: %d - %d \n", parent_score, child_score);
                }
                else if (parent == 'R' && child == 'R')
                {
                    printf("Parent : ROCK, Child : ROCK\n");
                    printf("Draw, Score: %d - %d \n", parent_score, child_score);
                }
                else
                {
                    printf("Parent : PAPER, Child : PAPER\n");
                    printf("Draw, Score: %d - %d \n", parent_score, child_score);
                }
            } //end game else
            kill(pid, SIGCONT);
            printf("--\n");
        } //end parent
    }while(!(pid < 0));
    return 0;
} //end main
