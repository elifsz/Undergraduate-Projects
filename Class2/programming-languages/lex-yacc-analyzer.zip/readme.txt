sudo apt-get install gcc make flex bison
make
Make test file=input1.txt
cat input1.txt
make clean