
import Person.Admin;
import Person.Member;
import Tour.CampingTour;
import Tour.CulturalTour;
import Tour.MixedTour;
import Tour.NaturalTour;
import Tour.SummerTour;
import Tour.Tour;
import Tour.WinterTour;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.table.DefaultTableModel;

public class Turkey extends javax.swing.JFrame {

    String tourname;
    String howmany;
    String price;
    String cap;
    String firstdate;
    String lastdate;
    String resim;
    String hotel;
    String beach;
    String bolge;
    String place;
    String cityname;
    String bungolow;
    String skiresortname;
    ArrayList<Member> memberLists = new ArrayList<>();
    ArrayList<JLabel> labelLists = new ArrayList<>();
    Admin admin = new Admin("heys", "hum", "hum", "tezcan");
    AdminFrame adm = new AdminFrame();
    ArrayList<JSpinner> spinners = new ArrayList<>();
    int count = 0;

    ArrayList<Basket> basket = new ArrayList<>();

    double totalmoney = 0.0;
    Member member = null;

    public void spinners() {

        spinners.add(s1);
        spinners.add(s2);
        spinners.add(s3);
        spinners.add(s4);
        spinners.add(s5);
        spinners.add(s6);
        spinners.add(s7);
        spinners.add(s8);
        spinners.add(s9);
        spinners.add(s10);

    }
    
    //read from file
    public void reading() {

        try {
            File belge = new File("SEHIRbelgesi.txt");
            Scanner readfile = new Scanner(belge);

            while (readfile.hasNext()) {
                String type = readfile.nextLine();
                if (type.equalsIgnoreCase("Summer")) {
                    tourname = readfile.nextLine();
                    howmany = readfile.nextLine();
                    price = readfile.nextLine();
                    cap = readfile.nextLine();
                    firstdate = readfile.nextLine();
                    String[] arr = firstdate.split("-");
                    int firstday = Integer.parseInt(arr[0]);
                    int firstmounth = Integer.parseInt(arr[1]);
                    int firstyear = Integer.parseInt(arr[2]);
                    lastdate = readfile.nextLine();
                    String[] arr2 = firstdate.split("-");
                    int lastday = Integer.parseInt(arr2[0]);
                    int lastmounth = Integer.parseInt(arr2[1]);
                    int lastyear = Integer.parseInt(arr2[2]);
                    resim = readfile.nextLine();
                    hotel = readfile.nextLine();
                    beach = readfile.nextLine();
                    bolge = readfile.nextLine();
                    place = readfile.nextLine();
                    readfile.nextLine();
                    admin.addTour(new SummerTour(hotel, beach, bolge, place, tourname, howmany, Integer.parseInt(cap), Double.parseDouble(price), firstday, firstmounth, firstyear, lastday, lastmounth, lastyear, resim));

                } else if (type.equalsIgnoreCase("Mixed")) {
                    tourname = readfile.nextLine();
                    howmany = readfile.nextLine();
                    cap = readfile.nextLine();
                    price = readfile.nextLine();
                    firstdate = readfile.nextLine();
                    String[] arr = firstdate.split("-");
                    int firstday = Integer.parseInt(arr[0]);
                    int firstmounth = Integer.parseInt(arr[1]);
                    int firstyear = Integer.parseInt(arr[2]);
                    lastdate = readfile.nextLine();
                    String[] arr2 = firstdate.split("-");
                    int lastday = Integer.parseInt(arr2[0]);
                    int lastmounth = Integer.parseInt(arr2[1]);
                    int lastyear = Integer.parseInt(arr2[2]);
                    resim = readfile.nextLine();
                    cityname = readfile.nextLine();
                    place = readfile.nextLine();
                    readfile.nextLine();
                    admin.addTour(new MixedTour(cityname, place, tourname, howmany, Integer.parseInt(cap), Double.parseDouble(price), firstday, firstmounth, firstyear, lastday, lastmounth, lastyear, resim));

                } else if (type.equalsIgnoreCase("Cultural")) {
                    tourname = readfile.nextLine();
                    howmany = readfile.nextLine();
                    cap = readfile.nextLine();
                    price = readfile.nextLine();
                    firstdate = readfile.nextLine();
                    String[] arr = firstdate.split("-");
                    int firstday = Integer.parseInt(arr[0]);
                    int firstmounth = Integer.parseInt(arr[1]);
                    int firstyear = Integer.parseInt(arr[2]);
                    lastdate = readfile.nextLine();
                    String[] arr2 = firstdate.split("-");
                    int lastday = Integer.parseInt(arr2[0]);
                    int lastmounth = Integer.parseInt(arr2[1]);
                    int lastyear = Integer.parseInt(arr2[2]);
                    resim = readfile.nextLine();
                    hotel = readfile.nextLine();
                    cityname = readfile.nextLine();
                    place = readfile.nextLine();
                    readfile.nextLine();
                    admin.addTour(new CulturalTour(hotel, cityname, place, tourname, howmany, Integer.parseInt(cap), Double.parseDouble(price), firstday, firstmounth, firstyear, lastday, lastmounth, lastyear, resim));

                } else if (type.equalsIgnoreCase("Natural")) {
                    tourname = readfile.nextLine();
                    howmany = readfile.nextLine();

                    cap = readfile.nextLine();
                    price = readfile.nextLine();
                    firstdate = readfile.nextLine();
                    String[] arr = firstdate.split("-");
                    int firstday = Integer.parseInt(arr[0]);
                    int firstmounth = Integer.parseInt(arr[1]);
                    int firstyear = Integer.parseInt(arr[2]);
                    lastdate = readfile.nextLine();
                    String[] arr2 = firstdate.split("-");
                    int lastday = Integer.parseInt(arr2[0]);
                    int lastmounth = Integer.parseInt(arr2[1]);
                    int lastyear = Integer.parseInt(arr2[2]);
                    resim = readfile.nextLine();
                    bungolow = readfile.nextLine();
                    place = readfile.nextLine();
                    bolge = readfile.nextLine();
                    readfile.nextLine();
                    admin.addTour(new NaturalTour(bungolow, bolge, place, tourname, howmany, Integer.parseInt(cap), Double.parseDouble(price), firstday, firstmounth, firstyear, lastday, lastmounth, lastyear, resim));
                    //System.out.println(admin.getAdmintours().get(admin.getAdmintours().size() - 1).toString() + "hello");
                } else if (type.equalsIgnoreCase("Winter")) {
                    tourname = readfile.nextLine();
                    howmany = readfile.nextLine();
                    price = readfile.nextLine();
                    cap = readfile.nextLine();
                    firstdate = readfile.nextLine();
                    String[] arr = firstdate.split("-");
                    int firstday = Integer.parseInt(arr[0]);
                    int firstmounth = Integer.parseInt(arr[1]);
                    int firstyear = Integer.parseInt(arr[2]);
                    lastdate = readfile.nextLine();
                    String[] arr2 = firstdate.split("-");
                    int lastday = Integer.parseInt(arr2[0]);
                    int lastmounth = Integer.parseInt(arr2[1]);
                    int lastyear = Integer.parseInt(arr2[2]);
                    resim = readfile.nextLine();
                    hotel = readfile.nextLine();
                    skiresortname = readfile.nextLine();
                    readfile.nextLine();

                    admin.addTour(new WinterTour(skiresortname, hotel, tourname, howmany, Integer.parseInt(cap), Double.parseDouble(price), firstday, firstmounth, firstyear, lastday, lastmounth, lastyear, resim));
                    //System.out.println(admin.getAdmintours().get(admin.getAdmintours().size() - 1).toString() + "hello");

                } else if (type.equalsIgnoreCase("Camping")) {
                    tourname = readfile.nextLine();
                    howmany = readfile.nextLine();
                    price = readfile.nextLine();
                    cap = readfile.nextLine();
                    firstdate = readfile.nextLine();
                    String[] arr = firstdate.split("-");
                    int firstday = Integer.parseInt(arr[0]);
                    int firstmounth = Integer.parseInt(arr[1]);
                    int firstyear = Integer.parseInt(arr[2]);
                    lastdate = readfile.nextLine();
                    String[] arr2 = firstdate.split("-");
                    int lastday = Integer.parseInt(arr2[0]);
                    int lastmounth = Integer.parseInt(arr2[1]);
                    int lastyear = Integer.parseInt(arr2[2]);
                    resim = readfile.nextLine();
                    place = readfile.nextLine();
                    readfile.nextLine();

                    admin.addTour(new CampingTour(place, tourname, howmany, Integer.parseInt(cap), Double.parseDouble(price), firstday, firstmounth, firstyear, lastday, lastmounth, lastyear, resim));
                }

            }

        } catch (Exception e) {
        }

    }

    public Turkey() {

        initComponents();
        adm.admin1 = admin;
        adm.basketlist = basket;

        sehirpanel.setVisible(false);
        reading();
        sepetekle.setVisible(false);
        sepet.setVisible(false);
        TourInfoFrame.setVisible(false);
        TourInfoFrame.setBounds(200, 200, 550, 560);
        BasketFrame.setBounds(101, 101, 500, 500);
        addButtonGroup();
        searchFrame.setVisible(false);
        searchFrame.setBounds(100, 100, 571, 800);
        spinners();
    }

    public void addButtonGroup() {
        types.add(naturalTourSearch);
        types.add(campingTourSearch);
        types.add(culturalTourSearch);
        types.add(mixedTourSearch);
        types.add(summerTourSearch);
        types.add(winterTourSearch);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        signs = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        signup = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        fSignUp = new javax.swing.JButton();
        signupName = new javax.swing.JTextField();
        signupEmail = new javax.swing.JTextField();
        signupTelephone = new javax.swing.JTextField();
        signupUsername = new javax.swing.JTextField();
        signupsurname = new javax.swing.JTextField();
        signupPassword = new javax.swing.JPasswordField();
        jButton2 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        signin = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        signInusername = new javax.swing.JTextField();
        fSignIn = new javax.swing.JButton();
        signinPassword = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        TourInfoFrame = new javax.swing.JFrame();
        sehirpanel = new javax.swing.JPanel();
        sepetekle = new javax.swing.JButton();
        sadecesehir = new javax.swing.JTextField();
        image = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        area = new javax.swing.JTextArea();
        jLabel21 = new javax.swing.JLabel();
        BasketFrame = new javax.swing.JFrame();
        jPanel2 = new javax.swing.JPanel();
        sepetpanel = new javax.swing.JPanel();
        satınal = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        baskettable = new javax.swing.JTable();
        satınal1 = new javax.swing.JButton();
        s1 = new javax.swing.JSpinner();
        s2 = new javax.swing.JSpinner();
        s3 = new javax.swing.JSpinner();
        s4 = new javax.swing.JSpinner();
        s5 = new javax.swing.JSpinner();
        s6 = new javax.swing.JSpinner();
        s7 = new javax.swing.JSpinner();
        s8 = new javax.swing.JSpinner();
        s9 = new javax.swing.JSpinner();
        s10 = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();
        buypanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cardnumber = new javax.swing.JTextField();
        month = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        year = new javax.swing.JTextField();
        cvc = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        cardname = new javax.swing.JTextField();
        cardsurname = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        adminLogin = new javax.swing.JFrame();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        usernameAdmin = new javax.swing.JTextField();
        adminLogIn = new javax.swing.JButton();
        passwordAdmin = new javax.swing.JPasswordField();
        jLabel24 = new javax.swing.JLabel();
        types = new javax.swing.ButtonGroup();
        searchFrame = new javax.swing.JFrame();
        jPanel5 = new javax.swing.JPanel();
        infomessage = new javax.swing.JScrollPane();
        bittimgozunaydin = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        findTourInfo = new javax.swing.JTextArea();
        infoMessage = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jButton1 = new javax.swing.JButton();
        btAdmin = new javax.swing.JButton();
        Turkey = new javax.swing.JPanel();
        rOsmaniye = new javax.swing.JLabel();
        rAfyon = new javax.swing.JLabel();
        rKutahya = new javax.swing.JLabel();
        rTunceli = new javax.swing.JLabel();
        rMus = new javax.swing.JLabel();
        rKirsehir = new javax.swing.JLabel();
        rAdiyaman = new javax.swing.JLabel();
        rBayburt = new javax.swing.JLabel();
        rSakarya = new javax.swing.JLabel();
        rBartin = new javax.swing.JLabel();
        rKaraman = new javax.swing.JLabel();
        rDuzce = new javax.swing.JLabel();
        rKocaeli = new javax.swing.JLabel();
        rKars = new javax.swing.JLabel();
        rArdahan = new javax.swing.JLabel();
        bilgi = new javax.swing.JLabel();
        rKirikkale = new javax.swing.JLabel();
        rKastamonu = new javax.swing.JLabel();
        rYozgat = new javax.swing.JLabel();
        rAdana = new javax.swing.JLabel();
        rArtvin = new javax.swing.JLabel();
        rBursa = new javax.swing.JLabel();
        rKirklareli = new javax.swing.JLabel();
        rTekirdag = new javax.swing.JLabel();
        rIstanbul = new javax.swing.JLabel();
        otekiCanakkale = new javax.swing.JLabel();
        rCanakkale = new javax.swing.JLabel();
        rEdirne = new javax.swing.JLabel();
        rZonguldak = new javax.swing.JLabel();
        rSinop = new javax.swing.JLabel();
        rTrabzon = new javax.swing.JLabel();
        rSamsun = new javax.swing.JLabel();
        rRize = new javax.swing.JLabel();
        rGiresun = new javax.swing.JLabel();
        rOrdu = new javax.swing.JLabel();
        rIgdir = new javax.swing.JLabel();
        rVan = new javax.swing.JLabel();
        rHakkari = new javax.swing.JLabel();
        rMardin = new javax.swing.JLabel();
        rUrfa = new javax.swing.JLabel();
        rMersin = new javax.swing.JLabel();
        rAntalya = new javax.swing.JLabel();
        rMugla = new javax.swing.JLabel();
        rIzmir = new javax.swing.JLabel();
        rAydin = new javax.swing.JLabel();
        rBatman = new javax.swing.JLabel();
        rAgri = new javax.swing.JLabel();
        rErzurum = new javax.swing.JLabel();
        rBitlis = new javax.swing.JLabel();
        rSiirt = new javax.swing.JLabel();
        rDiyarbakir = new javax.swing.JLabel();
        rBingol = new javax.swing.JLabel();
        rGumushane = new javax.swing.JLabel();
        rBalikesir = new javax.swing.JLabel();
        rErzincan = new javax.swing.JLabel();
        rElazig = new javax.swing.JLabel();
        rMalatya = new javax.swing.JLabel();
        rMaras = new javax.swing.JLabel();
        rKayseri = new javax.swing.JLabel();
        rTokat = new javax.swing.JLabel();
        rAmasya = new javax.swing.JLabel();
        rCorum = new javax.swing.JLabel();
        rCankiri = new javax.swing.JLabel();
        rKarabuk = new javax.swing.JLabel();
        rBolu = new javax.swing.JLabel();
        rNevsehir = new javax.swing.JLabel();
        rAksaray = new javax.swing.JLabel();
        rNigde = new javax.swing.JLabel();
        rIsparta = new javax.swing.JLabel();
        rBurdur = new javax.swing.JLabel();
        rDenizli = new javax.swing.JLabel();
        rManisa = new javax.swing.JLabel();
        rEskisehir = new javax.swing.JLabel();
        rKilis = new javax.swing.JLabel();
        rUsak = new javax.swing.JLabel();
        rBilecik = new javax.swing.JLabel();
        rAntep = new javax.swing.JLabel();
        rAnkara = new javax.swing.JLabel();
        rSivas = new javax.swing.JLabel();
        rKonya = new javax.swing.JLabel();
        rSirnak = new javax.swing.JLabel();
        rHatay = new javax.swing.JLabel();
        naber = new javax.swing.JLabel();
        welcome = new javax.swing.JLabel();
        btSignUp = new javax.swing.JButton();
        btSignIn = new javax.swing.JButton();
        sepet = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        winterTourSearch = new javax.swing.JRadioButton();
        summerTourSearch = new javax.swing.JRadioButton();
        mixedTourSearch = new javax.swing.JRadioButton();
        campingTourSearch = new javax.swing.JRadioButton();
        naturalTourSearch = new javax.swing.JRadioButton();
        culturalTourSearch = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        maxValue = new javax.swing.JSpinner();
        minValue = new javax.swing.JSpinner();
        searchButton = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();

        jPanel1.setLayout(new java.awt.CardLayout());

        signup.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 51));
        jLabel7.setText("Name:");
        signup.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 21, 53, 25));

        jLabel10.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 51));
        jLabel10.setText("E-Mail:");
        signup.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 114, 84, 25));

        jLabel11.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 51, 51));
        jLabel11.setText("Surname:");
        signup.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 64, 84, 25));

        jLabel12.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 51, 51));
        jLabel12.setText("Username:");
        signup.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 217, 101, 25));

        jLabel13.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 51, 51));
        jLabel13.setText("Password:");
        signup.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 271, 101, 25));

        jLabel14.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 51, 51));
        jLabel14.setText("Telephone:");
        signup.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 166, 101, 25));

        fSignUp.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        fSignUp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_add_user_male_30px.png"))); // NOI18N
        fSignUp.setText("Sign Up");
        fSignUp.setBorderPainted(false);
        fSignUp.setContentAreaFilled(false);
        fSignUp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        fSignUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fSignUpActionPerformed(evt);
            }
        });
        signup.add(fSignUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 309, 128, 45));

        signupName.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        signupName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 0, new java.awt.Color(0, 0, 102)));
        signupName.setOpaque(false);
        signup.add(signupName, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 21, 239, -1));

        signupEmail.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        signupEmail.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 0, new java.awt.Color(0, 0, 102)));
        signupEmail.setOpaque(false);
        signup.add(signupEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 114, 239, -1));

        signupTelephone.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        signupTelephone.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 0, new java.awt.Color(0, 0, 102)));
        signupTelephone.setOpaque(false);
        signup.add(signupTelephone, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 169, 239, -1));

        signupUsername.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        signupUsername.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 0, new java.awt.Color(0, 0, 102)));
        signupUsername.setOpaque(false);
        signup.add(signupUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 220, 239, -1));

        signupsurname.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        signupsurname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 0, new java.awt.Color(0, 0, 102)));
        signupsurname.setOpaque(false);
        signup.add(signupsurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 64, 239, -1));

        signupPassword.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        signupPassword.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 3, 0, new java.awt.Color(102, 0, 102)));
        signupPassword.setOpaque(false);
        signup.add(signupPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 271, 239, -1));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_delete_30px.png"))); // NOI18N
        jButton2.setText("Clear");
        jButton2.setBorderPainted(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setFocusPainted(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        signup.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 309, 98, -1));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backgrounds/loginbck.jpg"))); // NOI18N
        jLabel22.setText("jLabel22");
        signup.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -10, 520, 400));

        jPanel1.add(signup, "card2");

        signin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 51, 51));
        jLabel15.setText("Username:");
        signin.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 83, -1, 25));

        jLabel16.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 51, 51));
        jLabel16.setText("Password:");
        signin.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 82, 25));

        signInusername.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        signInusername.setAutoscrolls(false);
        signInusername.setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.gray, java.awt.Color.orange, java.awt.Color.blue, java.awt.Color.cyan), javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.gray)));
        signInusername.setOpaque(false);
        signin.add(signInusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(168, 81, 199, -1));

        fSignIn.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        fSignIn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_login_30px.png"))); // NOI18N
        fSignIn.setText("Log In");
        fSignIn.setBorderPainted(false);
        fSignIn.setContentAreaFilled(false);
        fSignIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        fSignIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fSignInActionPerformed(evt);
            }
        });
        signin.add(fSignIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 240, 128, 45));

        signinPassword.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        signinPassword.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 3, 0, new java.awt.Color(102, 0, 102)));
        signinPassword.setOpaque(false);
        signinPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                signinPasswordKeyPressed(evt);
            }
        });
        signin.add(signinPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 199, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backgrounds/loginbck.jpg"))); // NOI18N
        signin.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 510, 390));

        jPanel1.add(signin, "card3");

        javax.swing.GroupLayout signsLayout = new javax.swing.GroupLayout(signs.getContentPane());
        signs.getContentPane().setLayout(signsLayout);
        signsLayout.setHorizontalGroup(
            signsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        signsLayout.setVerticalGroup(
            signsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        sehirpanel.setBackground(new java.awt.Color(255, 204, 153));
        sehirpanel.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.MatteBorder(null), "Satın alma ve display"));
        sehirpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sepetekle.setBackground(new java.awt.Color(204, 102, 255));
        sepetekle.setFont(new java.awt.Font("Eras Demi ITC", 3, 18)); // NOI18N
        sepetekle.setForeground(new java.awt.Color(255, 255, 255));
        sepetekle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_shopping_cart_50px.png"))); // NOI18N
        sepetekle.setText("Add to Basket");
        sepetekle.setBorderPainted(false);
        sepetekle.setContentAreaFilled(false);
        sepetekle.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sepetekle.setFocusPainted(false);
        sepetekle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sepetekleActionPerformed(evt);
            }
        });
        sehirpanel.add(sepetekle, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 454, 270, 40));

        sadecesehir.setEditable(false);
        sadecesehir.setBackground(new java.awt.Color(230, 181, 255));
        sadecesehir.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        sadecesehir.setForeground(new java.awt.Color(102, 0, 102));
        sadecesehir.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        sehirpanel.add(sadecesehir, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 494, 50));

        image.setBackground(new java.awt.Color(0, 0, 0));
        image.setForeground(new java.awt.Color(0, 51, 51));
        sehirpanel.add(image, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 470, 218));

        area.setBackground(new java.awt.Color(255, 204, 255));
        area.setColumns(20);
        area.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        area.setRows(5);
        jScrollPane2.setViewportView(area);

        sehirpanel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 319, 152));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backgrounds/citypanelback.jpg"))); // NOI18N
        jLabel21.setText("jLabel21");
        sehirpanel.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -6, 530, 510));

        javax.swing.GroupLayout TourInfoFrameLayout = new javax.swing.GroupLayout(TourInfoFrame.getContentPane());
        TourInfoFrame.getContentPane().setLayout(TourInfoFrameLayout);
        TourInfoFrameLayout.setHorizontalGroup(
            TourInfoFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TourInfoFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sehirpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TourInfoFrameLayout.setVerticalGroup(
            TourInfoFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TourInfoFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sehirpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setLayout(new java.awt.CardLayout());

        sepetpanel.setBackground(new java.awt.Color(51, 255, 51));
        sepetpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        satınal.setBackground(new java.awt.Color(0, 153, 153));
        satınal.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        satınal.setText("BUY");
        satınal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                satınalActionPerformed(evt);
            }
        });
        sepetpanel.add(satınal, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 400, 150, 60));

        baskettable.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        baskettable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "TOUR NAME", "PRICE"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        baskettable.setRowHeight(33);
        jScrollPane4.setViewportView(baskettable);

        sepetpanel.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, 367, 356));

        satınal1.setBackground(new java.awt.Color(0, 153, 153));
        satınal1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        satınal1.setText("CANCEL");
        satınal1.setBorderPainted(false);
        satınal1.setContentAreaFilled(false);
        satınal1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        satınal1.setFocusPainted(false);
        satınal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                satınal1ActionPerformed(evt);
            }
        });
        sepetpanel.add(satınal1, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 472, 110, 20));

        s1.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s1, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 44, -1, -1));

        s2.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s2, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 79, -1, -1));

        s3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s3, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 113, -1, -1));

        s4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s4, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 147, -1, -1));

        s5.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s5, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 173, -1, -1));

        s6.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s6, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 210, -1, -1));

        s7.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s7, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 244, -1, -1));

        s8.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s8, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 280, -1, -1));

        s9.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s9, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 306, -1, -1));

        s10.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        sepetpanel.add(s10, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 337, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backgrounds/sepetarkaplan.jpg"))); // NOI18N
        sepetpanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-6, -6, 510, 510));

        jPanel2.add(sepetpanel, "card2");

        buypanel.setBackground(new java.awt.Color(255, 255, 255));
        buypanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setText("Card number");
        buypanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 55, 80, 32));

        jLabel6.setText("Expiration date");
        buypanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 93, 85, 21));

        jLabel8.setText("Security code");
        buypanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 120, 74, 31));

        jLabel9.setText("Card holder name");
        buypanel.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 157, 94, 26));
        buypanel.add(cardnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 61, 237, -1));

        month.setForeground(new java.awt.Color(51, 51, 51));
        month.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        buypanel.add(month, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 93, 79, -1));

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("/");
        buypanel.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 93, 27, 21));

        year.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        buypanel.add(year, new org.netbeans.lib.awtextra.AbsoluteConstraints(231, 93, 79, -1));
        buypanel.add(cvc, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 125, 76, 26));

        jLabel18.setBackground(new java.awt.Color(255, 255, 255));
        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 204, 0));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("Card Information");
        jLabel18.setOpaque(true);
        buypanel.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 11, 321, 26));
        buypanel.add(cardname, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 160, 101, -1));
        buypanel.add(cardsurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(224, 160, 101, -1));

        jButton5.setBackground(new java.awt.Color(255, 204, 0));
        jButton5.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jButton5.setText("BUY");
        jButton5.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton5.setBorderPainted(false);
        jButton5.setFocusPainted(false);
        jButton5.setFocusable(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        buypanel.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 120, 50));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backgrounds/cardback.jpg"))); // NOI18N
        jLabel4.setText("jLabel4");
        buypanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-6, 0, 510, 500));

        jPanel2.add(buypanel, "card3");

        javax.swing.GroupLayout BasketFrameLayout = new javax.swing.GroupLayout(BasketFrame.getContentPane());
        BasketFrame.getContentPane().setLayout(BasketFrameLayout);
        BasketFrameLayout.setHorizontalGroup(
            BasketFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BasketFrameLayout.setVerticalGroup(
            BasketFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 51, 51));
        jLabel19.setText("Username:");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 39, -1, 25));

        jLabel20.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 51, 51));
        jLabel20.setText("Password:");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 86, 82, 25));

        usernameAdmin.setFont(new java.awt.Font("Imprint MT Shadow", 1, 16)); // NOI18N
        usernameAdmin.setAutoscrolls(false);
        usernameAdmin.setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.gray, java.awt.Color.orange, java.awt.Color.blue, java.awt.Color.cyan), javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.gray)));
        usernameAdmin.setOpaque(false);
        jPanel3.add(usernameAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 37, 199, -1));

        adminLogIn.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        adminLogIn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_login_30px.png"))); // NOI18N
        adminLogIn.setText("Log In");
        adminLogIn.setBorderPainted(false);
        adminLogIn.setContentAreaFilled(false);
        adminLogIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        adminLogIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminLogInActionPerformed(evt);
            }
        });
        jPanel3.add(adminLogIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(229, 155, 128, 45));

        passwordAdmin.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        passwordAdmin.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 3, 0, new java.awt.Color(102, 0, 102)));
        passwordAdmin.setOpaque(false);
        passwordAdmin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                passwordAdminKeyPressed(evt);
            }
        });
        jPanel3.add(passwordAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 88, 199, -1));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backgrounds/login-bg.jpg"))); // NOI18N
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 320));

        javax.swing.GroupLayout adminLoginLayout = new javax.swing.GroupLayout(adminLogin.getContentPane());
        adminLogin.getContentPane().setLayout(adminLoginLayout);
        adminLoginLayout.setHorizontalGroup(
            adminLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        adminLoginLayout.setVerticalGroup(
            adminLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminLoginLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        searchFrame.setTitle("Search Result");

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bittimgozunaydin.setEditable(false);
        bittimgozunaydin.setColumns(20);
        bittimgozunaydin.setFont(new java.awt.Font("Yu Gothic Medium", 0, 14)); // NOI18N
        bittimgozunaydin.setRows(5);
        bittimgozunaydin.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information Area", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Tahoma", 0, 15))); // NOI18N
        infomessage.setViewportView(bittimgozunaydin);

        jPanel5.add(infomessage, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 490, 80));

        findTourInfo.setEditable(false);
        findTourInfo.setColumns(20);
        findTourInfo.setFont(new java.awt.Font("Yu Gothic Medium", 0, 13)); // NOI18N
        findTourInfo.setRows(5);
        jScrollPane1.setViewportView(findTourInfo);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 500, 580));

        infoMessage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/0bb0a21d29caa2227456dcfc325ebdff.jpg"))); // NOI18N
        infoMessage.setPreferredSize(new java.awt.Dimension(1000, 1063));
        jPanel5.add(infoMessage, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 570, 760));
        jPanel5.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 520, 500));

        javax.swing.GroupLayout searchFrameLayout = new javax.swing.GroupLayout(searchFrame.getContentPane());
        searchFrame.getContentPane().setLayout(searchFrameLayout);
        searchFrameLayout.setHorizontalGroup(
            searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        searchFrameLayout.setVerticalGroup(
            searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("HEYS TOURISM");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setFocusPainted(false);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1416, 191, -1, -1));

        btAdmin.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        btAdmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_crown_30px_1.png"))); // NOI18N
        btAdmin.setText("Admin");
        btAdmin.setBorderPainted(false);
        btAdmin.setContentAreaFilled(false);
        btAdmin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btAdmin.setFocusPainted(false);
        btAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAdminActionPerformed(evt);
            }
        });
        getContentPane().add(btAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        Turkey.setBackground(new java.awt.Color(102, 0, 153));
        Turkey.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rOsmaniye.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/osmaniye.png"))); // NOI18N
        rOsmaniye.setToolTipText("osmaniye");
        rOsmaniye.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rOsmaniyeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rOsmaniyeMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rOsmaniyeMousePressed(evt);
            }
        });
        Turkey.add(rOsmaniye, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 354, 50, 50));

        rAfyon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/afyon.png"))); // NOI18N
        rAfyon.setToolTipText("afyon");
        rAfyon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAfyonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAfyonMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAfyonMousePressed(evt);
            }
        });
        Turkey.add(rAfyon, new org.netbeans.lib.awtextra.AbsoluteConstraints(215, 251, -1, -1));

        rKutahya.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kutahya.png"))); // NOI18N
        rKutahya.setToolTipText("kütahya");
        rKutahya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rKutahyaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKutahyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKutahyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKutahyaMousePressed(evt);
            }
        });
        Turkey.add(rKutahya, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 204, -1, 80));

        rTunceli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/tunceli.png"))); // NOI18N
        rTunceli.setToolTipText("tunceli");
        rTunceli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rTunceliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rTunceliMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rTunceliMousePressed(evt);
            }
        });
        Turkey.add(rTunceli, new org.netbeans.lib.awtextra.AbsoluteConstraints(685, 214, -1, 70));

        rMus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/mus.png"))); // NOI18N
        rMus.setToolTipText("muş");
        rMus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rMusMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rMusMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rMusMousePressed(evt);
            }
        });
        Turkey.add(rMus, new org.netbeans.lib.awtextra.AbsoluteConstraints(805, 222, -1, -1));

        rKirsehir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kirsehir.png"))); // NOI18N
        rKirsehir.setToolTipText("kırşehir");
        rKirsehir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKirsehirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKirsehirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKirsehirMousePressed(evt);
            }
        });
        Turkey.add(rKirsehir, new org.netbeans.lib.awtextra.AbsoluteConstraints(413, 216, -1, 70));

        rAdiyaman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/adiyaman.png"))); // NOI18N
        rAdiyaman.setToolTipText("adiyaman");
        rAdiyaman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAdiyamanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAdiyamanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAdiyamanMousePressed(evt);
            }
        });
        Turkey.add(rAdiyaman, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 313, -1, 60));

        rBayburt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bayburt.png"))); // NOI18N
        rBayburt.setToolTipText("bayburt");
        rBayburt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBayburtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBayburtMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBayburtMousePressed(evt);
            }
        });
        Turkey.add(rBayburt, new org.netbeans.lib.awtextra.AbsoluteConstraints(727, 153, -1, 50));

        rSakarya.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/sakarya.png"))); // NOI18N
        rSakarya.setToolTipText("sakarya");
        rSakarya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rSakaryaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rSakaryaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rSakaryaMousePressed(evt);
            }
        });
        Turkey.add(rSakarya, new org.netbeans.lib.awtextra.AbsoluteConstraints(237, 123, 60, 60));

        rBartin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bartin.png"))); // NOI18N
        rBartin.setToolTipText("bartın");
        rBartin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBartinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBartinMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBartinMousePressed(evt);
            }
        });
        Turkey.add(rBartin, new org.netbeans.lib.awtextra.AbsoluteConstraints(346, 84, -1, -1));

        rKaraman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/karaman.png"))); // NOI18N
        rKaraman.setToolTipText("karaman");
        rKaraman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKaramanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKaramanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKaramanMousePressed(evt);
            }
        });
        Turkey.add(rKaraman, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 357, 90, 90));

        rDuzce.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/duzce.png"))); // NOI18N
        rDuzce.setToolTipText("düzce");
        rDuzce.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rDuzceMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rDuzceMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rDuzceMousePressed(evt);
            }
        });
        Turkey.add(rDuzce, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 126, -1, 40));

        rKocaeli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kocaeli.png"))); // NOI18N
        rKocaeli.setToolTipText("kocaeli");
        rKocaeli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKocaeliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKocaeliMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKocaeliMousePressed(evt);
            }
        });
        Turkey.add(rKocaeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 118, -1, 50));

        rKars.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kars.png"))); // NOI18N
        rKars.setToolTipText("kars");
        rKars.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKarsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKarsMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKarsMousePressed(evt);
            }
        });
        Turkey.add(rKars, new org.netbeans.lib.awtextra.AbsoluteConstraints(852, 110, -1, -1));

        rArdahan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/ardahan.png"))); // NOI18N
        rArdahan.setToolTipText("ardahan");
        rArdahan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rArdahanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rArdahanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rArdahanMousePressed(evt);
            }
        });
        Turkey.add(rArdahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(856, 81, -1, -1));

        bilgi.setFont(new java.awt.Font("Arial Narrow", 3, 36)); // NOI18N
        bilgi.setForeground(new java.awt.Color(255, 255, 102));
        bilgi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Turkey.add(bilgi, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 420, 280, 80));

        rKirikkale.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kirikkale.png"))); // NOI18N
        rKirikkale.setToolTipText("kırıkkale");
        rKirikkale.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKirikkaleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKirikkaleMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKirikkaleMousePressed(evt);
            }
        });
        Turkey.add(rKirikkale, new org.netbeans.lib.awtextra.AbsoluteConstraints(404, 184, -1, -1));

        rKastamonu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kastamonu.png"))); // NOI18N
        rKastamonu.setToolTipText("kastamonu");
        rKastamonu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKastamonuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKastamonuMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKastamonuMousePressed(evt);
            }
        });
        Turkey.add(rKastamonu, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 73, -1, -1));

        rYozgat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/yozgat.png"))); // NOI18N
        rYozgat.setToolTipText("Yozgat");
        rYozgat.setRequestFocusEnabled(false);
        rYozgat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rYozgatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rYozgatMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rYozgatMousePressed(evt);
            }
        });
        Turkey.add(rYozgat, new org.netbeans.lib.awtextra.AbsoluteConstraints(443, 189, -1, -1));

        rAdana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/adana.png"))); // NOI18N
        rAdana.setToolTipText("adana");
        rAdana.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAdanaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAdanaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAdanaMousePressed(evt);
            }
        });
        Turkey.add(rAdana, new org.netbeans.lib.awtextra.AbsoluteConstraints(481, 311, -1, -1));

        rArtvin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/artvin.png"))); // NOI18N
        rArtvin.setToolTipText("artvin");
        rArtvin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rArtvinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rArtvinMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rArtvinMousePressed(evt);
            }
        });
        Turkey.add(rArtvin, new org.netbeans.lib.awtextra.AbsoluteConstraints(793, 82, -1, -1));

        rBursa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bursa.png"))); // NOI18N
        rBursa.setToolTipText("bursa");
        rBursa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBursaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBursaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBursaMousePressed(evt);
            }
        });
        Turkey.add(rBursa, new org.netbeans.lib.awtextra.AbsoluteConstraints(143, 161, -1, -1));

        rKirklareli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kirklareli.png"))); // NOI18N
        rKirklareli.setToolTipText("kırklareli");
        rKirklareli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKirklareliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKirklareliMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKirklareliMousePressed(evt);
            }
        });
        Turkey.add(rKirklareli, new org.netbeans.lib.awtextra.AbsoluteConstraints(87, 56, -1, -1));

        rTekirdag.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/tekirdag.png"))); // NOI18N
        rTekirdag.setToolTipText("Tekirdağ");
        rTekirdag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rTekirdagMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rTekirdagMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rTekirdagMousePressed(evt);
            }
        });
        Turkey.add(rTekirdag, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 94, -1, -1));

        rIstanbul.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/istanbul.png"))); // NOI18N
        rIstanbul.setToolTipText("istanbul");
        rIstanbul.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rIstanbulMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rIstanbulMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rIstanbulMousePressed(evt);
            }
        });
        Turkey.add(rIstanbul, new org.netbeans.lib.awtextra.AbsoluteConstraints(129, 78, 130, -1));

        otekiCanakkale.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/canakkaleParca.png"))); // NOI18N
        otekiCanakkale.setToolTipText("");
        otekiCanakkale.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                otekiCanakkaleMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                otekiCanakkaleMouseReleased(evt);
            }
        });
        Turkey.add(otekiCanakkale, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 143, -1, -1));

        rCanakkale.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/canakkale.png"))); // NOI18N
        rCanakkale.setToolTipText("çanakkale");
        rCanakkale.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rCanakkaleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rCanakkaleMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rCanakkaleMousePressed(evt);
            }
        });
        Turkey.add(rCanakkale, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 163, -1, -1));

        rEdirne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/edirne.png"))); // NOI18N
        rEdirne.setToolTipText("Edirne");
        rEdirne.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rEdirneMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rEdirneMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rEdirneMousePressed(evt);
            }
        });
        Turkey.add(rEdirne, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 62, -1, -1));

        rZonguldak.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/zonguldak.png"))); // NOI18N
        rZonguldak.setToolTipText("zonguldak");
        rZonguldak.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rZonguldakMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rZonguldakMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rZonguldakMousePressed(evt);
            }
        });
        Turkey.add(rZonguldak, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 102, -1, -1));

        rSinop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/sinop.png"))); // NOI18N
        rSinop.setToolTipText("sinop");
        rSinop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rSinopMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rSinopMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rSinopMousePressed(evt);
            }
        });
        Turkey.add(rSinop, new org.netbeans.lib.awtextra.AbsoluteConstraints(454, 68, -1, -1));

        rTrabzon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/trabzon.png"))); // NOI18N
        rTrabzon.setToolTipText("trabzon");
        rTrabzon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rTrabzonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rTrabzonMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rTrabzonMousePressed(evt);
            }
        });
        Turkey.add(rTrabzon, new org.netbeans.lib.awtextra.AbsoluteConstraints(698, 125, -1, -1));

        rSamsun.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/samsun.png"))); // NOI18N
        rSamsun.setToolTipText("samsun");
        rSamsun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rSamsunMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rSamsunMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rSamsunMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                rSamsunMouseReleased(evt);
            }
        });
        Turkey.add(rSamsun, new org.netbeans.lib.awtextra.AbsoluteConstraints(485, 91, -1, -1));

        rRize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/rize.png"))); // NOI18N
        rRize.setToolTipText("rize");
        rRize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rRizeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rRizeMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rRizeMousePressed(evt);
            }
        });
        Turkey.add(rRize, new org.netbeans.lib.awtextra.AbsoluteConstraints(758, 105, -1, -1));

        rGiresun.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/giresun.png"))); // NOI18N
        rGiresun.setToolTipText("giresun");
        rGiresun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rGiresunMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rGiresunMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rGiresunMousePressed(evt);
            }
        });
        Turkey.add(rGiresun, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 130, -1, -1));

        rOrdu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/ordu.png"))); // NOI18N
        rOrdu.setToolTipText("ordu");
        rOrdu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rOrduMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rOrduMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rOrduMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                rOrduMouseReleased(evt);
            }
        });
        Turkey.add(rOrdu, new org.netbeans.lib.awtextra.AbsoluteConstraints(576, 128, -1, -1));

        rIgdir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/igdir.png"))); // NOI18N
        rIgdir.setToolTipText("ığdır");
        rIgdir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rIgdirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rIgdirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rIgdirMousePressed(evt);
            }
        });
        Turkey.add(rIgdir, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 172, -1, -1));

        rVan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/van.png"))); // NOI18N
        rVan.setToolTipText("van");
        rVan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rVanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rVanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rVanMousePressed(evt);
            }
        });
        Turkey.add(rVan, new org.netbeans.lib.awtextra.AbsoluteConstraints(893, 221, -1, -1));

        rHakkari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/hakkari.png"))); // NOI18N
        rHakkari.setToolTipText("hakkari");
        rHakkari.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rHakkariMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rHakkariMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rHakkariMousePressed(evt);
            }
        });
        Turkey.add(rHakkari, new org.netbeans.lib.awtextra.AbsoluteConstraints(929, 321, -1, -1));

        rMardin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/mardin.png"))); // NOI18N
        rMardin.setToolTipText("mardin");
        rMardin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rMardinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rMardinMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rMardinMousePressed(evt);
            }
        });
        Turkey.add(rMardin, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 331, 110, 80));

        rUrfa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/sanliurfa.png"))); // NOI18N
        rUrfa.setToolTipText("urfa");
        rUrfa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rUrfaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rUrfaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rUrfaMousePressed(evt);
            }
        });
        Turkey.add(rUrfa, new org.netbeans.lib.awtextra.AbsoluteConstraints(643, 330, -1, -1));

        rMersin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/mersin.png"))); // NOI18N
        rMersin.setToolTipText("mersin");
        rMersin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rMersinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rMersinMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rMersinMousePressed(evt);
            }
        });
        Turkey.add(rMersin, new org.netbeans.lib.awtextra.AbsoluteConstraints(366, 376, -1, -1));

        rAntalya.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/antalya.png"))); // NOI18N
        rAntalya.setToolTipText("antalya");
        rAntalya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAntalyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAntalyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAntalyaMousePressed(evt);
            }
        });
        Turkey.add(rAntalya, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 374, -1, -1));

        rMugla.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/mugla.png"))); // NOI18N
        rMugla.setToolTipText("muğla");
        rMugla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rMuglaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rMuglaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rMuglaMousePressed(evt);
            }
        });
        Turkey.add(rMugla, new org.netbeans.lib.awtextra.AbsoluteConstraints(84, 356, -1, -1));

        rIzmir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/izmir.png"))); // NOI18N
        rIzmir.setToolTipText("izmir");
        rIzmir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rIzmirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rIzmirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rIzmirMousePressed(evt);
            }
        });
        Turkey.add(rIzmir, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 234, -1, -1));

        rAydin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/aydin.png"))); // NOI18N
        rAydin.setToolTipText("aydın");
        rAydin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAydinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAydinMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAydinMousePressed(evt);
            }
        });
        Turkey.add(rAydin, new org.netbeans.lib.awtextra.AbsoluteConstraints(77, 321, -1, -1));

        rBatman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/batman.png"))); // NOI18N
        rBatman.setToolTipText("batman");
        rBatman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBatmanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBatmanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBatmanMousePressed(evt);
            }
        });
        Turkey.add(rBatman, new org.netbeans.lib.awtextra.AbsoluteConstraints(806, 286, 50, 70));

        rAgri.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/agri.png"))); // NOI18N
        rAgri.setToolTipText("ağrı");
        rAgri.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAgriMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAgriMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAgriMousePressed(evt);
            }
        });
        Turkey.add(rAgri, new org.netbeans.lib.awtextra.AbsoluteConstraints(863, 182, 120, 70));

        rErzurum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/erzurum.png"))); // NOI18N
        rErzurum.setToolTipText("erzurum");
        rErzurum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rErzurumMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rErzurumMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rErzurumMousePressed(evt);
            }
        });
        Turkey.add(rErzurum, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 125, 120, 120));

        rBitlis.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bitlis.png"))); // NOI18N
        rBitlis.setToolTipText("bitlis");
        rBitlis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBitlisMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBitlisMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBitlisMousePressed(evt);
            }
        });
        Turkey.add(rBitlis, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 251, -1, 70));

        rSiirt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/siirt.png"))); // NOI18N
        rSiirt.setToolTipText("siirt");
        rSiirt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rSiirtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rSiirtMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rSiirtMousePressed(evt);
            }
        });
        Turkey.add(rSiirt, new org.netbeans.lib.awtextra.AbsoluteConstraints(826, 299, -1, 50));

        rDiyarbakir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/diyarbakir.png"))); // NOI18N
        rDiyarbakir.setToolTipText("diyarbakır");
        rDiyarbakir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rDiyarbakirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rDiyarbakirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rDiyarbakirMousePressed(evt);
            }
        });
        Turkey.add(rDiyarbakir, new org.netbeans.lib.awtextra.AbsoluteConstraints(707, 271, -1, 90));

        rBingol.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bingol.png"))); // NOI18N
        rBingol.setToolTipText("bingöl");
        rBingol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBingolMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBingolMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBingolMousePressed(evt);
            }
        });
        Turkey.add(rBingol, new org.netbeans.lib.awtextra.AbsoluteConstraints(746, 220, -1, 80));

        rGumushane.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/gumushane.png"))); // NOI18N
        rGumushane.setToolTipText("gümüşhane");
        rGumushane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rGumushaneMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rGumushaneMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rGumushaneMousePressed(evt);
            }
        });
        Turkey.add(rGumushane, new org.netbeans.lib.awtextra.AbsoluteConstraints(682, 146, 70, 60));

        rBalikesir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/balikesir.png"))); // NOI18N
        rBalikesir.setToolTipText("balıkesir");
        rBalikesir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBalikesirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBalikesirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBalikesirMousePressed(evt);
            }
        });
        Turkey.add(rBalikesir, new org.netbeans.lib.awtextra.AbsoluteConstraints(64, 169, -1, 90));

        rErzincan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/erzincan.png"))); // NOI18N
        rErzincan.setToolTipText("erzincan");
        rErzincan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rErzincanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rErzincanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rErzincanMousePressed(evt);
            }
        });
        Turkey.add(rErzincan, new org.netbeans.lib.awtextra.AbsoluteConstraints(662, 192, 120, 70));

        rElazig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/elazig.png"))); // NOI18N
        rElazig.setToolTipText("elazığ");
        rElazig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rElazigMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rElazigMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rElazigMousePressed(evt);
            }
        });
        Turkey.add(rElazig, new org.netbeans.lib.awtextra.AbsoluteConstraints(667, 244, -1, 70));

        rMalatya.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/malatya.png"))); // NOI18N
        rMalatya.setToolTipText("malatya");
        rMalatya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rMalatyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rMalatyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rMalatyaMousePressed(evt);
            }
        });
        Turkey.add(rMalatya, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 253, -1, 90));

        rMaras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/maras.png"))); // NOI18N
        rMaras.setToolTipText("kahramanmaraş");
        rMaras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rMarasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rMarasMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rMarasMousePressed(evt);
            }
        });
        Turkey.add(rMaras, new org.netbeans.lib.awtextra.AbsoluteConstraints(557, 292, -1, 100));

        rKayseri.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kayseri.png"))); // NOI18N
        rKayseri.setToolTipText("kayseri");
        rKayseri.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKayseriMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKayseriMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKayseriMousePressed(evt);
            }
        });
        Turkey.add(rKayseri, new org.netbeans.lib.awtextra.AbsoluteConstraints(487, 252, -1, 100));

        rTokat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/tokat.png"))); // NOI18N
        rTokat.setToolTipText("tokat");
        rTokat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rTokatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rTokatMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rTokatMousePressed(evt);
            }
        });
        Turkey.add(rTokat, new org.netbeans.lib.awtextra.AbsoluteConstraints(514, 140, -1, 70));

        rAmasya.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/amasya.png"))); // NOI18N
        rAmasya.setToolTipText("amasya");
        rAmasya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAmasyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAmasyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAmasyaMousePressed(evt);
            }
        });
        Turkey.add(rAmasya, new org.netbeans.lib.awtextra.AbsoluteConstraints(491, 131, -1, 60));

        rCorum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/corum.png"))); // NOI18N
        rCorum.setToolTipText("çorum");
        rCorum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rCorumMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rCorumMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rCorumMousePressed(evt);
            }
        });
        Turkey.add(rCorum, new org.netbeans.lib.awtextra.AbsoluteConstraints(438, 113, -1, 100));

        rCankiri.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/cankiri.png"))); // NOI18N
        rCankiri.setToolTipText("çankırı");
        rCankiri.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rCankiriMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rCankiriMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rCankiriMousePressed(evt);
            }
        });
        Turkey.add(rCankiri, new org.netbeans.lib.awtextra.AbsoluteConstraints(369, 131, -1, 60));

        rKarabuk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/karabuk.png"))); // NOI18N
        rKarabuk.setToolTipText("karabük");
        rKarabuk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKarabukMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKarabukMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKarabukMousePressed(evt);
            }
        });
        Turkey.add(rKarabuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 95, -1, 60));

        rBolu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bolu.png"))); // NOI18N
        rBolu.setToolTipText("bolu");
        rBolu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBoluMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBoluMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBoluMousePressed(evt);
            }
        });
        Turkey.add(rBolu, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 135, -1, 60));

        rNevsehir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/nevsehir.png"))); // NOI18N
        rNevsehir.setToolTipText("nevşehir");
        rNevsehir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rNevsehirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rNevsehirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rNevsehirMousePressed(evt);
            }
        });
        Turkey.add(rNevsehir, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 245, -1, 70));

        rAksaray.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/aksaray.png"))); // NOI18N
        rAksaray.setToolTipText("aksaray");
        rAksaray.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAksarayMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAksarayMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAksarayMousePressed(evt);
            }
        });
        Turkey.add(rAksaray, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 264, -1, 80));

        rNigde.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/nigde.png"))); // NOI18N
        rNigde.setToolTipText("niğde");
        rNigde.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rNigdeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rNigdeMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rNigdeMousePressed(evt);
            }
        });
        Turkey.add(rNigde, new org.netbeans.lib.awtextra.AbsoluteConstraints(443, 305, 70, 80));

        rIsparta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/isparta.png"))); // NOI18N
        rIsparta.setToolTipText("ısparta");
        rIsparta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rIspartaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rIspartaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rIspartaMousePressed(evt);
            }
        });
        Turkey.add(rIsparta, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 300, -1, 80));

        rBurdur.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/burdur.png"))); // NOI18N
        rBurdur.setToolTipText("burdur");
        rBurdur.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBurdurMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBurdurMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBurdurMousePressed(evt);
            }
        });
        Turkey.add(rBurdur, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 345, -1, 60));

        rDenizli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/denizli.png"))); // NOI18N
        rDenizli.setToolTipText("denizli");
        rDenizli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rDenizliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rDenizliMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rDenizliMousePressed(evt);
            }
        });
        Turkey.add(rDenizli, new org.netbeans.lib.awtextra.AbsoluteConstraints(157, 297, -1, 110));

        rManisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/manisa.png"))); // NOI18N
        rManisa.setToolTipText("manisa");
        rManisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rManisaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rManisaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rManisaMousePressed(evt);
            }
        });
        Turkey.add(rManisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(86, 228, -1, 100));

        rEskisehir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/eskisehir.png"))); // NOI18N
        rEskisehir.setToolTipText("eskişehir");
        rEskisehir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rEskisehirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rEskisehirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rEskisehirMousePressed(evt);
            }
        });
        Turkey.add(rEskisehir, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 193, -1, 70));

        rKilis.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/kilis.png"))); // NOI18N
        rKilis.setToolTipText("kilis");
        rKilis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKilisMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKilisMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKilisMousePressed(evt);
            }
        });
        Turkey.add(rKilis, new org.netbeans.lib.awtextra.AbsoluteConstraints(585, 389, -1, 40));

        rUsak.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/usak.png"))); // NOI18N
        rUsak.setToolTipText("uşak");
        rUsak.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rUsakMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rUsakMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rUsakMousePressed(evt);
            }
        });
        Turkey.add(rUsak, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 263, 70, 60));

        rBilecik.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/bilecik.png"))); // NOI18N
        rBilecik.setToolTipText("bilecik");
        rBilecik.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rBilecikMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rBilecikMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rBilecikMousePressed(evt);
            }
        });
        Turkey.add(rBilecik, new org.netbeans.lib.awtextra.AbsoluteConstraints(224, 165, 50, 60));

        rAntep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/gaziantep.png"))); // NOI18N
        rAntep.setToolTipText("antep");
        rAntep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAntepMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAntepMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAntepMousePressed(evt);
            }
        });
        Turkey.add(rAntep, new org.netbeans.lib.awtextra.AbsoluteConstraints(571, 361, 90, 60));

        rAnkara.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/ankara.png"))); // NOI18N
        rAnkara.setToolTipText("Ankara");
        rAnkara.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rAnkaraMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rAnkaraMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rAnkaraMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rAnkaraMousePressed(evt);
            }
        });
        Turkey.add(rAnkara, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 159, -1, -1));

        rSivas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/sivas.png"))); // NOI18N
        rSivas.setToolTipText("sivas");
        rSivas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rSivasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rSivasMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rSivasMousePressed(evt);
            }
        });
        Turkey.add(rSivas, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 162, -1, 140));

        rKonya.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/konya.png"))); // NOI18N
        rKonya.setToolTipText("Konya");
        rKonya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rKonyaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rKonyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rKonyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rKonyaMousePressed(evt);
            }
        });
        Turkey.add(rKonya, new org.netbeans.lib.awtextra.AbsoluteConstraints(298, 247, -1, 180));

        rSirnak.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/sirnak.png"))); // NOI18N
        rSirnak.setToolTipText("şırnak");
        rSirnak.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rSirnakMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rSirnakMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rSirnakMousePressed(evt);
            }
        });
        Turkey.add(rSirnak, new org.netbeans.lib.awtextra.AbsoluteConstraints(839, 328, 100, 50));

        rHatay.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resimler/hatay.png"))); // NOI18N
        rHatay.setToolTipText("hatay");
        rHatay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                rHatayMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                rHatayMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rHatayMousePressed(evt);
            }
        });
        Turkey.add(rHatay, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 402, -1, 70));

        getContentPane().add(Turkey, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 92, 1022, 517));

        naber.setFont(new java.awt.Font("Yu Gothic UI", 1, 30)); // NOI18N
        naber.setForeground(new java.awt.Color(51, 51, 51));
        naber.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        naber.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_turkey_30px.png"))); // NOI18N
        naber.setText("Welcome");
        getContentPane().add(naber, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 23, 225, -1));

        welcome.setFont(new java.awt.Font("Yu Gothic UI", 1, 28)); // NOI18N
        getContentPane().add(welcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(499, 27, 365, 37));

        btSignUp.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        btSignUp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_add_user_male_30px.png"))); // NOI18N
        btSignUp.setText("Sign Up");
        btSignUp.setBorderPainted(false);
        btSignUp.setContentAreaFilled(false);
        btSignUp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btSignUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSignUpActionPerformed(evt);
            }
        });
        getContentPane().add(btSignUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 26, -1, -1));

        btSignIn.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        btSignIn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_login_30px.png"))); // NOI18N
        btSignIn.setText("Sign In");
        btSignIn.setBorderPainted(false);
        btSignIn.setContentAreaFilled(false);
        btSignIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btSignIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSignInActionPerformed(evt);
            }
        });
        getContentPane().add(btSignIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1156, 23, 128, 45));

        sepet.setFont(new java.awt.Font("Tempus Sans ITC", 1, 16)); // NOI18N
        sepet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_add_shopping_cart_50px.png"))); // NOI18N
        sepet.setText("Basket");
        sepet.setBorderPainted(false);
        sepet.setContentAreaFilled(false);
        sepet.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sepet.setFocusPainted(false);
        sepet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sepetActionPerformed(evt);
            }
        });
        getContentPane().add(sepet, new org.netbeans.lib.awtextra.AbsoluteConstraints(869, 16, 154, -1));

        jPanel4.setBackground(new java.awt.Color(183, 183, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search ", javax.swing.border.TitledBorder.LEADING, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tempus Sans ITC", 1, 18))); // NOI18N

        winterTourSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        winterTourSearch.setForeground(new java.awt.Color(0, 102, 102));
        winterTourSearch.setText("Winter");
        winterTourSearch.setContentAreaFilled(false);
        winterTourSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                winterTourSearchActionPerformed(evt);
            }
        });

        summerTourSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        summerTourSearch.setForeground(new java.awt.Color(0, 102, 102));
        summerTourSearch.setText("Summer");
        summerTourSearch.setContentAreaFilled(false);
        summerTourSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                summerTourSearchActionPerformed(evt);
            }
        });

        mixedTourSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        mixedTourSearch.setForeground(new java.awt.Color(0, 102, 102));
        mixedTourSearch.setText("Mixed");
        mixedTourSearch.setContentAreaFilled(false);
        mixedTourSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mixedTourSearchActionPerformed(evt);
            }
        });

        campingTourSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        campingTourSearch.setForeground(new java.awt.Color(0, 102, 102));
        campingTourSearch.setText("Camping");
        campingTourSearch.setContentAreaFilled(false);
        campingTourSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campingTourSearchActionPerformed(evt);
            }
        });

        naturalTourSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        naturalTourSearch.setForeground(new java.awt.Color(0, 102, 102));
        naturalTourSearch.setText("Natural");
        naturalTourSearch.setContentAreaFilled(false);
        naturalTourSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                naturalTourSearchActionPerformed(evt);
            }
        });

        culturalTourSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        culturalTourSearch.setForeground(new java.awt.Color(0, 102, 102));
        culturalTourSearch.setText("Cultural");
        culturalTourSearch.setContentAreaFilled(false);
        culturalTourSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                culturalTourSearchActionPerformed(evt);
            }
        });

        jSeparator1.setForeground(new java.awt.Color(0, 102, 102));
        jSeparator1.setPreferredSize(new java.awt.Dimension(50, 20));

        jLabel2.setFont(new java.awt.Font("Yu Gothic Medium", 1, 16)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_turkish_lira_50px.png"))); // NOI18N
        jLabel2.setText(" min   -   max");

        maxValue.setFont(new java.awt.Font("Yu Gothic Medium", 1, 16)); // NOI18N

        minValue.setFont(new java.awt.Font("Yu Gothic Medium", 1, 16)); // NOI18N
        minValue.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        searchButton.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); // NOI18N
        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_google_web_search_40px.png"))); // NOI18N
        searchButton.setText("Search");
        searchButton.setBorderPainted(false);
        searchButton.setContentAreaFilled(false);
        searchButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 17, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(winterTourSearch)
                                    .addComponent(summerTourSearch)
                                    .addComponent(naturalTourSearch)
                                    .addComponent(culturalTourSearch)
                                    .addComponent(campingTourSearch)
                                    .addComponent(mixedTourSearch)))
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(minValue, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(maxValue, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(campingTourSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(culturalTourSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(naturalTourSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(summerTourSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(winterTourSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mixedTourSearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(minValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maxValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(searchButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 157, -1, -1));

        jLabel26.setBackground(new java.awt.Color(183, 183, 255));
        jLabel26.setOpaque(true);
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1450, 90));

        jLabel23.setBackground(new java.awt.Color(102, 0, 153));
        jLabel23.setOpaque(true);
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1450, 700));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAdminActionPerformed
        adminLogin.setBounds(100, 100, 390, 350);
        adminLogin.setVisible(true);

    }//GEN-LAST:event_btAdminActionPerformed

    private void rMusMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMusMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mus1.png"));
        rMus.setIcon(img);
        bilgi.setText("MUŞ");
    }//GEN-LAST:event_rMusMouseEntered

    private void rMusMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMusMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mus.png"));
        rMus.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rMusMouseExited

    private void rBayburtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBayburtMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bayburt1.png"));
        rBayburt.setIcon(img);
        bilgi.setText("BAYBURT");
    }//GEN-LAST:event_rBayburtMouseEntered

    private void rBayburtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBayburtMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bayburt.png"));
        rBayburt.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBayburtMouseExited

    private void rSakaryaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSakaryaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sakarya1.png"));
        rSakarya.setIcon(img);
        bilgi.setText("SAKARYA");
    }//GEN-LAST:event_rSakaryaMouseEntered

    private void rSakaryaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSakaryaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sakarya.png"));
        rSakarya.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rSakaryaMouseExited

    private void rBartinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBartinMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bartin1.png"));
        rBartin.setIcon(img);
        bilgi.setText("BARTIN");
    }//GEN-LAST:event_rBartinMouseEntered

    private void rBartinMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBartinMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bartin.png"));
        rBartin.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBartinMouseExited

    private void rKaramanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKaramanMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/karaman1.png"));
        rKaraman.setIcon(img);
        bilgi.setText("KARAMAN");
    }//GEN-LAST:event_rKaramanMouseEntered

    private void rKaramanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKaramanMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/karaman.png"));
        rKaraman.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKaramanMouseExited

    private void rDuzceMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDuzceMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/duzce1.png"));
        rDuzce.setIcon(img);
        bilgi.setText("DÜZCE");
    }//GEN-LAST:event_rDuzceMouseEntered

    private void rDuzceMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDuzceMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/duzce.png"));
        rDuzce.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rDuzceMouseExited

    private void rKocaeliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKocaeliMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kocaeli1.png"));
        rKocaeli.setIcon(img);
        bilgi.setText("KOCAELİ");
    }//GEN-LAST:event_rKocaeliMouseEntered

    private void rKocaeliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKocaeliMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kocaeli.png"));
        rKocaeli.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKocaeliMouseExited

    private void rKarsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKarsMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kars1.png"));
        rKars.setIcon(img);
        bilgi.setText("KARS");
    }//GEN-LAST:event_rKarsMouseEntered

    private void rKarsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKarsMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kars.png"));
        rKars.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKarsMouseExited

    private void rArdahanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rArdahanMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/ardahan1.png"));
        rArdahan.setIcon(img);
        bilgi.setText("ARDAHAN");
    }//GEN-LAST:event_rArdahanMouseEntered

    private void rArdahanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rArdahanMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/ardahan.png"));
        rArdahan.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rArdahanMouseExited

    private void rAnkaraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAnkaraMouseClicked

    }//GEN-LAST:event_rAnkaraMouseClicked

    private void rAnkaraMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAnkaraMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/ankara1.png"));
        rAnkara.setIcon(img);
        bilgi.setText("ANKARA");
    }//GEN-LAST:event_rAnkaraMouseEntered

    private void rAnkaraMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAnkaraMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/ankara.png"));
        rAnkara.setIcon(img);
    }//GEN-LAST:event_rAnkaraMouseExited

    private void rKirikkaleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirikkaleMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kirikkale1.png"));
        rKirikkale.setIcon(img);
        bilgi.setText("KIRIKKALE");
    }//GEN-LAST:event_rKirikkaleMouseEntered

    private void rKirikkaleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirikkaleMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kirikkale.png"));
        rKirikkale.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKirikkaleMouseExited

    private void rKastamonuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKastamonuMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kastamonu1.png"));
        rKastamonu.setIcon(img);
        bilgi.setText("KASTAMONU");
    }//GEN-LAST:event_rKastamonuMouseEntered

    private void rKastamonuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKastamonuMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kastamonu.png"));
        rKastamonu.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKastamonuMouseExited

    private void rYozgatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rYozgatMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/yozgat1.png"));
        rYozgat.setIcon(img);
        bilgi.setText("YOZGAT");
    }//GEN-LAST:event_rYozgatMouseEntered

    private void rYozgatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rYozgatMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/yozgat.png"));
        rYozgat.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rYozgatMouseExited

    private void rAdanaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAdanaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/adana1.png"));
        rAdana.setIcon(img);
        bilgi.setText("ADANA");
    }//GEN-LAST:event_rAdanaMouseEntered

    private void rAdanaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAdanaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/adana.png"));
        rAdana.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAdanaMouseExited

    private void rArtvinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rArtvinMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/artvin1.png"));
        rArtvin.setIcon(img);
        bilgi.setText("ARTVİN");
    }//GEN-LAST:event_rArtvinMouseEntered

    private void rArtvinMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rArtvinMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/artvin.png"));
        rArtvin.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rArtvinMouseExited

    private void rBursaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBursaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bursa1.png"));
        rBursa.setIcon(img);
        bilgi.setText("BURSA");
    }//GEN-LAST:event_rBursaMouseEntered

    private void rBursaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBursaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bursa.png"));
        rBursa.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBursaMouseExited

    private void rKirklareliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirklareliMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kirklareli1.png"));
        rKirklareli.setIcon(img);
        bilgi.setText("KIRKLARELİ");
    }//GEN-LAST:event_rKirklareliMouseEntered

    private void rKirklareliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirklareliMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kirklareli.png"));
        rKirklareli.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKirklareliMouseExited

    private void rTekirdagMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTekirdagMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/tekirdag1.png"));
        rTekirdag.setIcon(img);
        bilgi.setText("TEKİRDAĞ");
    }//GEN-LAST:event_rTekirdagMouseEntered

    private void rTekirdagMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTekirdagMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/tekirdag.png"));
        rTekirdag.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rTekirdagMouseExited

    private void rIstanbulMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIstanbulMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/istanbul1.png"));
        rIstanbul.setIcon(img);
        bilgi.setText("İSTANBUL");
    }//GEN-LAST:event_rIstanbulMouseEntered

    private void rIstanbulMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIstanbulMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/istanbul.png"));
        rIstanbul.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rIstanbulMouseExited

    private void rCanakkaleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCanakkaleMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/canakkale1.png"));
        ImageIcon img1 = new ImageIcon(getClass().getResource("resimler/canakkaleParca1.png"));
        rCanakkale.setIcon(img);
        otekiCanakkale.setIcon(img1);
        bilgi.setText("ÇANAKKALE");
    }//GEN-LAST:event_rCanakkaleMouseEntered

    private void rCanakkaleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCanakkaleMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/canakkale.png"));
        ImageIcon img1 = new ImageIcon(getClass().getResource("resimler/canakkaleParca.png"));
        rCanakkale.setIcon(img);
        otekiCanakkale.setIcon(img1);
        bilgi.setText("");
    }//GEN-LAST:event_rCanakkaleMouseExited

    private void rEdirneMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rEdirneMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/edirne1.png"));
        rEdirne.setIcon(img);
        bilgi.setText("EDİRNE");
    }//GEN-LAST:event_rEdirneMouseEntered

    private void rEdirneMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rEdirneMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/edirne.png"));
        rEdirne.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rEdirneMouseExited

    private void rZonguldakMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rZonguldakMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/zonguldak1.png"));
        rZonguldak.setIcon(img);
        bilgi.setText("ZONGULDAK");
    }//GEN-LAST:event_rZonguldakMouseEntered

    private void rZonguldakMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rZonguldakMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/zonguldak.png"));
        rZonguldak.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rZonguldakMouseExited

    private void rSinopMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSinopMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sinop1.png"));
        rSinop.setIcon(img);
        bilgi.setText("SİNOP");
    }//GEN-LAST:event_rSinopMouseEntered

    private void rSinopMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSinopMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sinop.png"));
        rSinop.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rSinopMouseExited

    private void rTrabzonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTrabzonMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/trabzon1.png"));
        rTrabzon.setIcon(img);
        bilgi.setText("TRABZON");
    }//GEN-LAST:event_rTrabzonMouseEntered

    private void rTrabzonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTrabzonMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/trabzon.png"));
        rTrabzon.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rTrabzonMouseExited

    private void rSamsunMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSamsunMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/samsun1.png"));
        rSamsun.setIcon(img);
        bilgi.setText("SAMSUN");
    }//GEN-LAST:event_rSamsunMouseEntered

    private void rSamsunMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSamsunMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/samsun.png"));
        rSamsun.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rSamsunMouseExited

    private void rRizeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rRizeMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/rize1.png"));
        rRize.setIcon(img);
        bilgi.setText("RİZE");
    }//GEN-LAST:event_rRizeMouseEntered

    private void rRizeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rRizeMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/rize.png"));
        rRize.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rRizeMouseExited

    private void rGiresunMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rGiresunMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/giresun1.png"));
        rGiresun.setIcon(img);
        bilgi.setText("GIRESUN");
    }//GEN-LAST:event_rGiresunMouseEntered

    private void rGiresunMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rGiresunMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/giresun.png"));
        rGiresun.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rGiresunMouseExited

    private void rOrduMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOrduMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/ordu1.png"));
        rOrdu.setIcon(img);
        bilgi.setText("ORDU");
    }//GEN-LAST:event_rOrduMouseEntered

    private void rOrduMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOrduMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/ordu.png"));
        rOrdu.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rOrduMouseExited

    private void rIgdirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIgdirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/igdir1.png"));
        rIgdir.setIcon(img);
        bilgi.setText("IĞDIR");
    }//GEN-LAST:event_rIgdirMouseEntered

    private void rIgdirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIgdirMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/igdir.png"));
        rIgdir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rIgdirMouseExited

    private void rVanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rVanMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/van1.png"));
        rVan.setIcon(img);
        bilgi.setText("VAN");
    }//GEN-LAST:event_rVanMouseEntered

    private void rVanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rVanMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/van.png"));
        rVan.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rVanMouseExited

    private void rHakkariMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rHakkariMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/hakkari1.png"));
        rHakkari.setIcon(img);
        bilgi.setText("HAKKARİ");
    }//GEN-LAST:event_rHakkariMouseEntered

    private void rHakkariMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rHakkariMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/hakkari.png"));
        rHakkari.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rHakkariMouseExited

    private void rMardinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMardinMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mardin1.png"));
        rMardin.setIcon(img);
        bilgi.setText("MARDİN");
    }//GEN-LAST:event_rMardinMouseEntered

    private void rMardinMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMardinMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mardin.png"));
        rMardin.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rMardinMouseExited

    private void rUrfaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rUrfaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sanliurfa1.png"));
        rUrfa.setIcon(img);
        bilgi.setText("ŞANLIURFA");
    }//GEN-LAST:event_rUrfaMouseEntered

    private void rUrfaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rUrfaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sanliurfa.png"));
        rUrfa.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rUrfaMouseExited

    private void rMersinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMersinMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mersin1.png"));
        rMersin.setIcon(img);
        bilgi.setText("MERSİN");
    }//GEN-LAST:event_rMersinMouseEntered

    private void rMersinMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMersinMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mersin.png"));
        rMersin.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rMersinMouseExited

    private void rAntalyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAntalyaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/antalya1.png"));
        rAntalya.setIcon(img);
        bilgi.setText("ANTALYA");
    }//GEN-LAST:event_rAntalyaMouseEntered

    private void rAntalyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAntalyaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/antalya.png"));
        rAntalya.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAntalyaMouseExited

    private void rMuglaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMuglaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mugla1.png"));
        rMugla.setIcon(img);
        bilgi.setText("MUĞLA");
    }//GEN-LAST:event_rMuglaMouseEntered

    private void rMuglaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMuglaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/mugla.png"));
        rMugla.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rMuglaMouseExited

    private void rIzmirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIzmirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/izmir1.png"));
        rIzmir.setIcon(img);
        bilgi.setText("İZMİR");
    }//GEN-LAST:event_rIzmirMouseEntered

    private void rIzmirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIzmirMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/izmir.png"));
        rIzmir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rIzmirMouseExited

    private void rAydinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAydinMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/aydin1.png"));
        rAydin.setIcon(img);
        bilgi.setText("AYDIN");
    }//GEN-LAST:event_rAydinMouseEntered

    private void rAydinMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAydinMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/aydin.png"));
        rAydin.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAydinMouseExited

    private void rAgriMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAgriMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/agri1.png"));
        rAgri.setIcon(img);
        bilgi.setText("AĞRI");
    }//GEN-LAST:event_rAgriMouseEntered

    private void rAgriMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAgriMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/agri.png"));
        rAgri.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAgriMouseExited

    private void rErzurumMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rErzurumMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/erzurum1.png"));
        rErzurum.setIcon(img);
        bilgi.setText("ERZURUM");
    }//GEN-LAST:event_rErzurumMouseEntered

    private void rErzurumMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rErzurumMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/erzurum.png"));
        rErzurum.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rErzurumMouseExited

    private void rBitlisMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBitlisMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bitlis1.png"));
        rBitlis.setIcon(img);
        bilgi.setText("BİTLİS");
    }//GEN-LAST:event_rBitlisMouseEntered

    private void rBitlisMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBitlisMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bitlis.png"));
        rBitlis.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBitlisMouseExited

    private void rSiirtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSiirtMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/siirt1.png"));
        rSiirt.setIcon(img);
        bilgi.setText("SİİRT");
    }//GEN-LAST:event_rSiirtMouseEntered

    private void rSiirtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSiirtMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/siirt.png"));
        rSiirt.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rSiirtMouseExited

    private void rBatmanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBatmanMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/batman1.png"));
        rBatman.setIcon(img);
        bilgi.setText("BATMAN");
    }//GEN-LAST:event_rBatmanMouseEntered

    private void rBatmanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBatmanMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/batman.png"));
        rBatman.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBatmanMouseExited

    private void rDiyarbakirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDiyarbakirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/diyarbakir1.png"));
        rDiyarbakir.setIcon(img);
        bilgi.setText("DİYARBAKIR");
    }//GEN-LAST:event_rDiyarbakirMouseEntered

    private void rDiyarbakirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDiyarbakirMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/diyarbakir.png"));
        rDiyarbakir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rDiyarbakirMouseExited

    private void rBingolMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBingolMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bingol1.png"));
        rBingol.setIcon(img);
        bilgi.setText("BİNGÖL");
    }//GEN-LAST:event_rBingolMouseEntered

    private void rBingolMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBingolMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bingol.png"));
        rBingol.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBingolMouseExited

    private void rGumushaneMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rGumushaneMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/gumushane1.png"));
        rGumushane.setIcon(img);
        bilgi.setText("GÜMÜŞHANE");
    }//GEN-LAST:event_rGumushaneMouseEntered

    private void rGumushaneMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rGumushaneMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/gumushane.png"));
        rGumushane.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rGumushaneMouseExited

    private void rBalikesirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBalikesirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/balikesir1.png"));
        rBalikesir.setIcon(img);
        bilgi.setText("BALIKESİR");
    }//GEN-LAST:event_rBalikesirMouseEntered

    private void rBalikesirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBalikesirMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/balikesir.png"));
        rBalikesir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBalikesirMouseExited

    private void rErzincanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rErzincanMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/erzincan1.png"));
        rErzincan.setIcon(img);
        bilgi.setText("ERZİNCAN");
    }//GEN-LAST:event_rErzincanMouseEntered

    private void rErzincanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rErzincanMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/erzincan.png"));
        rErzincan.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rErzincanMouseExited

    private void rSivasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSivasMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sivas1.png"));
        rSivas.setIcon(img);
        bilgi.setText("SİVAS");
    }//GEN-LAST:event_rSivasMouseEntered

    private void rSivasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSivasMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sivas.png"));
        rSivas.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rSivasMouseExited

    private void rKonyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKonyaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/konya1.png"));
        rKonya.setIcon(img);
        bilgi.setText("KONYA");
    }//GEN-LAST:event_rKonyaMouseEntered

    private void rKonyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKonyaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/konya.png"));
        rKonya.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKonyaMouseExited

    private void rElazigMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rElazigMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/elazig1.png"));
        rElazig.setIcon(img);
        bilgi.setText("ELAZIĞ");
    }//GEN-LAST:event_rElazigMouseEntered

    private void rElazigMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rElazigMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/elazig.png"));
        rElazig.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rElazigMouseExited

    private void rTunceliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTunceliMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/tunceli1.png"));
        rTunceli.setIcon(img);
        bilgi.setText("TUNCELİ");
    }//GEN-LAST:event_rTunceliMouseEntered

    private void rTunceliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTunceliMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/tunceli.png"));
        rTunceli.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rTunceliMouseExited

    private void rMalatyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMalatyaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/malatya1.png"));
        rMalatya.setIcon(img);
        bilgi.setText("MALATYA");
    }//GEN-LAST:event_rMalatyaMouseEntered

    private void rMalatyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMalatyaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/malatya.png"));
        rMalatya.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rMalatyaMouseExited

    private void rMarasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMarasMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/maras1.png"));
        rMaras.setIcon(img);
        bilgi.setText("KAHRAMANMARAŞ");
    }//GEN-LAST:event_rMarasMouseEntered

    private void rMarasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMarasMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/maras.png"));
        rMaras.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rMarasMouseExited

    private void rKayseriMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKayseriMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kayseri1.png"));
        rKayseri.setIcon(img);
        bilgi.setText("KAYSERİ");
    }//GEN-LAST:event_rKayseriMouseEntered

    private void rKayseriMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKayseriMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kayseri.png"));
        rKayseri.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKayseriMouseExited

    private void rTokatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTokatMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/tokat1.png"));
        rTokat.setIcon(img);
        bilgi.setText("TOKAT");
    }//GEN-LAST:event_rTokatMouseEntered

    private void rTokatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTokatMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/tokat.png"));
        rTokat.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rTokatMouseExited

    private void rAmasyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAmasyaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/amasya1.png"));
        rAmasya.setIcon(img);
        bilgi.setText("AMASYA");
    }//GEN-LAST:event_rAmasyaMouseEntered

    private void rAmasyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAmasyaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/amasya.png"));
        rAmasya.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAmasyaMouseExited

    private void rCorumMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCorumMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/corum1.png"));
        rCorum.setIcon(img);
        bilgi.setText("ÇORUM");
    }//GEN-LAST:event_rCorumMouseEntered

    private void rCorumMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCorumMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/corum.png"));
        rCorum.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rCorumMouseExited

    private void rCankiriMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCankiriMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/cankiri1.png"));
        rCankiri.setIcon(img);
        bilgi.setText("ÇANKIRI");
    }//GEN-LAST:event_rCankiriMouseEntered

    private void rCankiriMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCankiriMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/cankiri.png"));
        rCankiri.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rCankiriMouseExited

    private void rKarabukMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKarabukMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/karabuk1.png"));
        rKarabuk.setIcon(img);
        bilgi.setText("KARABÜK");
    }//GEN-LAST:event_rKarabukMouseEntered

    private void rKarabukMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKarabukMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/karabuk.png"));
        rKarabuk.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKarabukMouseExited

    private void rBoluMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBoluMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bolu1.png"));
        rBolu.setIcon(img);
        bilgi.setText("BOLU");
    }//GEN-LAST:event_rBoluMouseEntered

    private void rBoluMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBoluMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bolu.png"));
        rBolu.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBoluMouseExited

    private void rAdiyamanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAdiyamanMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/adiyaman1.png"));
        rAdiyaman.setIcon(img);
        bilgi.setText("ADIYAMAN");
    }//GEN-LAST:event_rAdiyamanMouseEntered

    private void rAdiyamanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAdiyamanMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/adiyaman.png"));
        rAdiyaman.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAdiyamanMouseExited

    private void rKirsehirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirsehirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kirsehir1.png"));
        rKirsehir.setIcon(img);
        bilgi.setText("KIRŞEHİR");
    }//GEN-LAST:event_rKirsehirMouseEntered

    private void rKirsehirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirsehirMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kirsehir.png"));
        rKirsehir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKirsehirMouseExited

    private void rNevsehirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rNevsehirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/nevsehir1.png"));
        rNevsehir.setIcon(img);
        bilgi.setText("NEVŞEHİR");
    }//GEN-LAST:event_rNevsehirMouseEntered

    private void rNevsehirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rNevsehirMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/nevsehir.png"));
        rNevsehir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rNevsehirMouseExited

    private void rAksarayMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAksarayMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/aksaray1.png"));
        rAksaray.setIcon(img);
        bilgi.setText("AKSARAY");
    }//GEN-LAST:event_rAksarayMouseEntered

    private void rAksarayMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAksarayMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/aksaray.png"));
        rAksaray.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAksarayMouseExited

    private void rNigdeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rNigdeMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/nigde1.png"));
        rNigde.setIcon(img);
        bilgi.setText("NİĞDE");
    }//GEN-LAST:event_rNigdeMouseEntered

    private void rNigdeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rNigdeMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/nigde.png"));
        rNigde.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rNigdeMouseExited

    private void rIspartaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIspartaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/isparta1.png"));
        rIsparta.setIcon(img);
        bilgi.setText("ISPARTA");
    }//GEN-LAST:event_rIspartaMouseEntered

    private void rIspartaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIspartaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/isparta.png"));
        rIsparta.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rIspartaMouseExited

    private void rBurdurMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBurdurMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/burdur1.png"));
        rBurdur.setIcon(img);
        bilgi.setText("BURDUR");
    }//GEN-LAST:event_rBurdurMouseEntered

    private void rBurdurMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBurdurMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/burdur.png"));
        rBurdur.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBurdurMouseExited

    private void rDenizliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDenizliMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/denizli1.png"));
        rDenizli.setIcon(img);
        bilgi.setText("DENİZLİ");
    }//GEN-LAST:event_rDenizliMouseEntered

    private void rDenizliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDenizliMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/denizli.png"));
        rDenizli.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rDenizliMouseExited

    private void rManisaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rManisaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/manisa1.png"));
        rManisa.setIcon(img);
        bilgi.setText("MANİSA");
    }//GEN-LAST:event_rManisaMouseEntered

    private void rManisaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rManisaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/manisa.png"));
        rManisa.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rManisaMouseExited

    private void rEskisehirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rEskisehirMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/eskisehir1.png"));
        rEskisehir.setIcon(img);
        bilgi.setText("ESKİŞEHİR");
    }//GEN-LAST:event_rEskisehirMouseEntered

    private void rEskisehirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rEskisehirMouseExited
        // TODO add your handling code here:
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/eskisehir.png"));
        rEskisehir.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rEskisehirMouseExited

    private void rKutahyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKutahyaMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kutahya1.png"));
        rKutahya.setIcon(img);
        bilgi.setText("KÜTAHYA");
    }//GEN-LAST:event_rKutahyaMouseEntered

    private void rKutahyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKutahyaMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kutahya.png"));
        rKutahya.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKutahyaMouseExited

    private void rKilisMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKilisMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kilis1.png"));
        rKilis.setIcon(img);
        bilgi.setText("KİLİS");
    }//GEN-LAST:event_rKilisMouseEntered

    private void rKilisMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKilisMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/kilis.png"));
        rKilis.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rKilisMouseExited

    private void rUsakMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rUsakMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/usak1.png"));
        rUsak.setIcon(img);
        bilgi.setText("UŞAK");
    }//GEN-LAST:event_rUsakMouseEntered

    private void rUsakMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rUsakMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/usak.png"));
        rUsak.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rUsakMouseExited

    private void rOsmaniyeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOsmaniyeMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/osmaniye1.png"));
        rOsmaniye.setIcon(img);
        bilgi.setText("OSMANİYE");
    }//GEN-LAST:event_rOsmaniyeMouseEntered

    private void rOsmaniyeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOsmaniyeMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/osmaniye.png"));
        rOsmaniye.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rOsmaniyeMouseExited

    private void rBilecikMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBilecikMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bilecik1.png"));
        rBilecik.setIcon(img);
        bilgi.setText("BİLECİK");
    }//GEN-LAST:event_rBilecikMouseEntered

    private void rBilecikMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBilecikMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/bilecik.png"));
        rBilecik.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rBilecikMouseExited

    private void rAntepMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAntepMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/gaziantep1.png"));
        rAntep.setIcon(img);
        bilgi.setText("GAZİANTEP");
    }//GEN-LAST:event_rAntepMouseEntered

    private void rAntepMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAntepMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/gaziantep.png"));
        rAntep.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAntepMouseExited

    private void rSirnakMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSirnakMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sirnak1.png"));
        rSirnak.setIcon(img);
        bilgi.setText("ŞIRNAK");
    }//GEN-LAST:event_rSirnakMouseEntered

    private void rSirnakMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSirnakMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/sirnak.png"));
        rSirnak.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rSirnakMouseExited

    private void rHatayMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rHatayMouseEntered
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/hatay1.png"));

        rHatay.setIcon(img);
        bilgi.setText("HATAY");
    }//GEN-LAST:event_rHatayMouseEntered

    private void rHatayMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rHatayMouseExited
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/hatay.png"));
        rHatay.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rHatayMouseExited

    private void rKutahyaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKutahyaMouseClicked

    }//GEN-LAST:event_rKutahyaMouseClicked

    private void rKonyaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKonyaMouseClicked


    }//GEN-LAST:event_rKonyaMouseClicked

//The method used to become a member and print the member to the file also checks 
//that the user name has not been used before
    private void fSignUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fSignUpActionPerformed
        String name;
        String surname;
        String mail;
        String telephone;
        String username;
        String password;

        try {
            name = signupName.getText();
            surname = signupsurname.getText();
            mail = signupEmail.getText();
            telephone = signupTelephone.getText();
            username = signupUsername.getText();
            password = signupPassword.getText();
            int control = 0;
            if (name.isEmpty() || surname.isEmpty() || mail.isEmpty() || telephone.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Some blank is empty!!", "Error", JOptionPane.INFORMATION_MESSAGE);

            } else {

                System.out.println("hello");
                System.out.println(memberLists.toString());

                for (int i = 0; i < memberLists.size(); i++) {
                    if (memberLists.get(i).getUserName().compareTo(username) == 0) {
                        JOptionPane.showMessageDialog(null, "The username has used!", "Used Username", JOptionPane.NO_OPTION);
                        control = 1;
                        break;
                    }

                }
                if (control != 1) {
                    memberLists.add(new Member(name, surname, mail, telephone, username, password));

                    welcome.setText("Welcome  " + name + " " + surname);
                    btSignIn.setVisible(false);
                    btSignUp.setVisible(false);
                    sepetekle.setVisible(true);
                    sepet.setVisible(true);
                }

                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt", true));
                    writer.write(username + "\n");
                    writer.write(password + "\n");
                    writer.write(name + "\n");
                    writer.write(surname + "\n");
                    writer.write(mail + "\n");
                    writer.write(telephone + "\n");
                    writer.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            if (control == 1) {
                sepetekle.setVisible(false);
                sepet.setVisible(false);
                welcome.setText("");
            }
            signs.setVisible(false);
            signup.setVisible(false);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Try again!", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_fSignUpActionPerformed
//method used to log in.
    private void fSignInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fSignInActionPerformed
        boolean kontrol = false;
        String username;
        String password;
        int control = 0;
        try {
            username = signInusername.getText();
            password = signinPassword.getText();
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Some blank is empty!!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (memberLists.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Empty List!", "Error", JOptionPane.WARNING_MESSAGE);
            } else {
                for (int i = 0; i < memberLists.size(); i++) {
                    if (memberLists.get(i).check(username, password)) {
                        signs.setVisible(false);
                        signin.setVisible(false);
                        welcome.setText("hello " + memberLists.get(i).getName() + " " + memberLists.get(i).getSurname());
                        btSignIn.setVisible(false);
                        btSignUp.setVisible(false);
                        control = 1;
                        kontrol = true;
                        sepetekle.setVisible(true);
                        sepet.setVisible(true);
                        break;
                    }
                }
                if (control == 0) {

                    sepetekle.setVisible(false);
                    sepet.setVisible(false);
                    JOptionPane.showMessageDialog(null, "wrong username or password!", "Error", JOptionPane.ERROR_MESSAGE);
                    welcome.setText("");
                }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Try again!", "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_fSignInActionPerformed
    //reads users in the file and opens the login frame.
    private void btSignInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSignInActionPerformed
        // TODO add your handling code here:
        String name;
        String surname;
        String mail;
        String telephone;
        String username;
        String password;
        try {
            File reader2 = new File("members.txt");
            Scanner reader = new Scanner(reader2);
            while (reader.hasNext()) {
                username = reader.nextLine();
                password = reader.nextLine();
                name = reader.nextLine();
                surname = reader.nextLine();
                mail = reader.nextLine();
                telephone = reader.nextLine();
                member = new Member(name, surname, mail, telephone, username, password);
                memberLists.add(member);

            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        signs.setBounds(200, 250, 500, 450);
        signs.setVisible(true);
        signup.setVisible(false);
        signin.setVisible(true);
    }//GEN-LAST:event_btSignInActionPerformed
    // reads users in the file and opens the sign up screen.
    private void btSignUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSignUpActionPerformed
        String name;
        String surname;
        String mail;
        String telephone;
        String username;
        String password;
        try {
            File reader2 = new File("members.txt");
            Scanner reader = new Scanner(reader2);
            while (reader.hasNext()) {
                username = reader.nextLine();
                password = reader.nextLine();
                name = reader.nextLine();
                surname = reader.nextLine();
                mail = reader.nextLine();
                telephone = reader.nextLine();
                member = new Member(name, surname, mail, telephone, username, password);
                memberLists.add(member);

            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        signs.setBounds(200, 250, 500, 450);
        signs.setVisible(true);
        signin.setVisible(false);
        signup.setVisible(true);
    }//GEN-LAST:event_btSignUpActionPerformed
//clear, signup textfields
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        signupEmail.setText("");
        signupName.setText("");
        signupPassword.setText("");
        signupTelephone.setText("");
        signupUsername.setText("");
        signupsurname.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void satınalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_satınalActionPerformed
        BasketFrame.setVisible(true);
        sepetpanel.setVisible(false);
        buypanel.setVisible(true);
        DefaultTableModel model = (DefaultTableModel) baskettable.getModel();

        ArrayList<Integer> howmanytours = new ArrayList<>();
        double totalprice = 0.0;

        for (int i = 0; i < model.getRowCount(); i++) {

            howmanytours.add((int) spinners.get(i).getValue());
            basket.get(i).setHowmany(howmanytours.get(i));
            totalprice += (basket.get(i).price) * howmanytours.get(i);

        }

    }//GEN-LAST:event_satınalActionPerformed

    private void satınal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_satınal1ActionPerformed
        BasketFrame.setVisible(false);
    }//GEN-LAST:event_satınal1ActionPerformed

    private void rAntalyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAntalyaMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Antalya Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Antalya");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAntalyaMousePressed

    private void sepetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sepetActionPerformed
        BasketFrame.setVisible(true);
        sepetpanel.setVisible(true);
        buypanel.setVisible(false);
        DefaultTableModel model1 = (DefaultTableModel) baskettable.getModel();
        model1.setRowCount(0);
        for (int i = 0; i < basket.size(); i++) {
            model1.addRow(new Object[]{basket.get(i).TourName, basket.get(i).price});
        }
    }//GEN-LAST:event_sepetActionPerformed

    private void adminLogInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminLogInActionPerformed
        String username = usernameAdmin.getText().trim();
        String passWord = passwordAdmin.getText();

        if (admin.check(username, passWord)) {
            adm.setVisible(true);
            adminLogin.setVisible(false);
            usernameAdmin.setText("");
            passwordAdmin.setText("");
        } else {
            JOptionPane.showMessageDialog(null, "wrong username or password!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_adminLogInActionPerformed

    private void passwordAdminKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passwordAdminKeyPressed
        String username = usernameAdmin.getText().trim();
        String passWord = passwordAdmin.getText();
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (admin.check(username, passWord)) {
                adm.setVisible(true);
                adminLogin.setVisible(false);
                usernameAdmin.setText("");
                passwordAdmin.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "wrong username or password!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        }
    }//GEN-LAST:event_passwordAdminKeyPressed

    private void rYozgatMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rYozgatMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Yozgat Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("yozgat");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rYozgatMousePressed
    //this method gives the index of the type of cultural tour.

    public ArrayList<Integer> searchedCulturalTour() {
        ArrayList<Integer> indexCultural = new ArrayList<>();

        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            if (adm.admin1.getAdmintours().get(i) instanceof CulturalTour) {
                indexCultural.add(i);
            }

        }
        return indexCultural;
    }
//this method gives the index of the type of mixed tour.

    public ArrayList<Integer> searchedMixedTour() {
        ArrayList<Integer> indexMixed = new ArrayList<>();

        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            if (adm.admin1.getAdmintours().get(i) instanceof MixedTour) {
                indexMixed.add(i);
            }

        }
        return indexMixed;
    }
    //this method gives the index of the type of winter tour.

    public ArrayList<Integer> searchedWinterTour() {
        ArrayList<Integer> indexWinter = new ArrayList<>();

        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            if (adm.admin1.getAdmintours().get(i) instanceof WinterTour) {
                indexWinter.add(i);
            }

        }
        return indexWinter;
    }
    //this method gives the index of the type of summer tour.

    public ArrayList<Integer> searchedSummerTour() {
        ArrayList<Integer> indexSummer = new ArrayList<>();

        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            if (adm.admin1.getAdmintours().get(i) instanceof SummerTour) {
                indexSummer.add(i);
            }

        }
        return indexSummer;
    }
//this method gives the index of the type of natural tour.

    public ArrayList<Integer> searchedNaturalTour() {
        ArrayList<Integer> indexNatural = new ArrayList<>();

        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            if (adm.admin1.getAdmintours().get(i) instanceof NaturalTour) {
                indexNatural.add(i);
            }

        }
        return indexNatural;
    }
//this method gives the index of the type of camping tour.

    public ArrayList<Integer> searchedCampingTour() {
        ArrayList<Integer> indexCamping = new ArrayList<>();
        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            if (adm.admin1.getAdmintours().get(i) instanceof CampingTour) {
                indexCamping.add(i);
            }
        }
        return indexCamping;
    }

//press radio button and prints camping tours info.
    private void campingTourSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campingTourSearchActionPerformed
        findTourInfo.setText("");
        bittimgozunaydin.setText("");
        ArrayList<Integer> camping;
        camping = searchedCampingTour();
        for (int i = 0; i < camping.size(); i++) {
            CampingTour ct = (CampingTour) adm.admin1.getAdmintours().get(camping.get(i));
            findTourInfo.append(ct.getTourName() + "-->" + ct.getPrice()
                    + "₺\nCamping Area: " + ct.getPlaceToCampingArea() + "\n\n");
        }
        searchFrame.setVisible(true);
        CampingTour ct = new CampingTour();
        bittimgozunaydin.setText(ct.informationMessage());

    }//GEN-LAST:event_campingTourSearchActionPerformed
//press radio button and prints cultural tours info.
    private void culturalTourSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_culturalTourSearchActionPerformed
        findTourInfo.setText("");
        bittimgozunaydin.setText("");
        ArrayList<Integer> cultural;
        cultural = searchedCulturalTour();
        for (int i = 0; i < cultural.size(); i++) {
            CulturalTour ct = (CulturalTour) adm.admin1.getAdmintours().get(cultural.get(i));
            findTourInfo.append(ct.getTourName() + "-->" + ct.getPrice()
                    + "₺\nPlace to Visit: " + ct.getPlace_to_visit() + "\n\n");
        }
        searchFrame.setVisible(true);
        CulturalTour ct = new CulturalTour();
        bittimgozunaydin.setText(ct.informationMessage());

    }//GEN-LAST:event_culturalTourSearchActionPerformed
//press radio button and prints natural tours info.
    private void naturalTourSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_naturalTourSearchActionPerformed
        findTourInfo.setText("");
        bittimgozunaydin.setText("");
        ArrayList<Integer> natural;
        natural = searchedNaturalTour();
        for (int i = 0; i < natural.size(); i++) {
            NaturalTour nt = (NaturalTour) adm.admin1.getAdmintours().get(natural.get(i));
            findTourInfo.append(nt.getTourName() + "-->" + nt.getPrice()
                    + "₺\nPlace to Visit: " + nt.getPlace_to_visit() + "\n\n");
        }
        searchFrame.setVisible(true);
        NaturalTour ct = new NaturalTour();
        bittimgozunaydin.setText(ct.informationMessage());

    }//GEN-LAST:event_naturalTourSearchActionPerformed
//press radio button and prints summer tours info.
    private void summerTourSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_summerTourSearchActionPerformed
        findTourInfo.setText("");
        bittimgozunaydin.setText("");
        ArrayList<Integer> summer;
        summer = searchedSummerTour();
        for (int i = 0; i < summer.size(); i++) {
            SummerTour nt = (SummerTour) adm.admin1.getAdmintours().get(summer.get(i));
            findTourInfo.append(nt.getTourName() + "-->" + nt.getPrice()
                    + "₺\nPlace to Visit: " + nt.getPlace_to_visit()
                    + "\nBeach Name: " + nt.getBeachName() + "\n\n");
        }
        searchFrame.setVisible(true);
        SummerTour ct = new SummerTour();
        bittimgozunaydin.setText(ct.informationMessage());

    }//GEN-LAST:event_summerTourSearchActionPerformed
//press radio button and prints winter tours info.
    private void winterTourSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_winterTourSearchActionPerformed
        findTourInfo.setText("");
        bittimgozunaydin.setText("");
        ArrayList<Integer> winter;
        winter = searchedWinterTour();
        for (int i = 0; i < winter.size(); i++) {
            WinterTour nt = (WinterTour) adm.admin1.getAdmintours().get(winter.get(i));
            findTourInfo.append(nt.getTourName() + "-->" + nt.getPrice()
                    + "₺\nSki Resort Name: " + nt.getSkiResortName() + "\n\n");
        }
        searchFrame.setVisible(true);
        WinterTour ct = new WinterTour();
        bittimgozunaydin.setText(ct.informationMessage());
    }//GEN-LAST:event_winterTourSearchActionPerformed

//press radio button and prints mixed tours info.
    private void mixedTourSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mixedTourSearchActionPerformed
        findTourInfo.setText("");
        bittimgozunaydin.setText("");
        ArrayList<Integer> mixed;
        mixed = searchedMixedTour();
        for (int i = 0; i < mixed.size(); i++) {
            MixedTour nt = (MixedTour) adm.admin1.getAdmintours().get(mixed.get(i));
            findTourInfo.append(nt.getTourName() + "-->" + nt.getPrice()
                    + "₺\nPlace to Visit: " + nt.getPlace_to_visit() + "\n\n");
        }
        searchFrame.setVisible(true);
        MixedTour ct = new MixedTour();
        bittimgozunaydin.setText(ct.informationMessage());

    }//GEN-LAST:event_mixedTourSearchActionPerformed
    //This method allows you to search the admin's tours according to the given value range 
    //and give the indexes of the appropriate ones.

    public ArrayList<Integer> paraArama(double min, double max) {
        ArrayList<Integer> money = new ArrayList<>();
        for (int i = 0; i < adm.admin1.getAdmintours().size(); i++) {
            double price = adm.admin1.getAdmintours().get(i).getPrice();
            if (price > min & price < max) {
                money.add(i);
            }
            if (min > max) {
                JOptionPane.showMessageDialog(null, "min value is can not greater than max value", "Error", JOptionPane.ERROR_MESSAGE);
                break;
            }
        }
        return money;
    }
    //prints the prices of the tours sorting within the desired value range.
    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        findTourInfo.setText("");
        String mins = minValue.getValue().toString();
        double min = Double.parseDouble(mins);
        String maxs = maxValue.getValue().toString();
        double max = Double.parseDouble(maxs);

        ArrayList<Integer> money = paraArama(min, max);
        ArrayList<Tour> tours = new ArrayList<>();

        for (int i = 0; i < money.size(); i++) {
            tours.add(adm.admin1.getAdmintours().get(money.get(i)));
        }

        int sizeTour = tours.size();

        for (int i = 0; i < sizeTour - 1; i++) {
            for (int j = 0; j < sizeTour - i - 1; j++) {
                if (tours.get(j).getPrice() > tours.get(j + 1).getPrice()) {
                    Collections.swap(tours, j, j + 1);
                }
            }
        }
        for (int i = 0; i < sizeTour; i++) {
            findTourInfo.append(tours.get(i).getTourName() + "-->" + tours.get(i).getPrice() + "₺\n");
            searchFrame.setVisible(true);
        }
        bittimgozunaydin.setText("");


    }//GEN-LAST:event_searchButtonActionPerformed

    private void sepetekleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sepetekleActionPerformed
        for (int i = 0; i < admin.contentWith(sadecesehir.getText()).size(); i++) {
            basket.add(new Basket(sadecesehir.getText(), admin.contentWith(sadecesehir.getText()).get(i).getPrice()));

        }
        TourInfoFrame.setVisible(false);

    }//GEN-LAST:event_sepetekleActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (cardnumber.getText().equalsIgnoreCase("") || cardname.getText().equalsIgnoreCase("") || cardnumber.getText().equalsIgnoreCase("") || cardsurname.getText().equalsIgnoreCase("") || cvc.getText().equalsIgnoreCase("") || month.getText().equalsIgnoreCase("") || year.getText().equalsIgnoreCase("")) {

            JOptionPane.showMessageDialog(null, "Please fill all empty areas correctly", "ERROR", JOptionPane.ERROR_MESSAGE);

        } else {
            int total = 0;
            String tot = "";
            for (int i = 0; i < basket.size(); i++) {
                if (basket.get(i).howmany > 0) {
                    total += basket.get(i).howmany * basket.get(i).price;
                    tot += basket.get(i).toString() + "\nPrice :" + basket.get(i).howmany * basket.get(i).price + "\n";
                }
            }
            JOptionPane.showMessageDialog(null, "YOU BOUGHT YOUR TOUR(S)\n" + tot + "\nTotal price: " + total, "THANK YOU", JOptionPane.INFORMATION_MESSAGE);
        }


    }//GEN-LAST:event_jButton5ActionPerformed

    private void rKonyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKonyaMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Konya Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Konya");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKonyaMousePressed

    private void rEdirneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rEdirneMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Edirne Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Edirne");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rEdirneMousePressed

    private void rKirklareliMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirklareliMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kirklareli Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kirklareli");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKirklareliMousePressed

    private void rTekirdagMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTekirdagMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Tekirdag Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Tekirdag");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rTekirdagMousePressed

    private void otekiCanakkaleMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_otekiCanakkaleMouseReleased
    }//GEN-LAST:event_otekiCanakkaleMouseReleased

    private void otekiCanakkaleMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_otekiCanakkaleMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Canakkale Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Canakkale");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_otekiCanakkaleMousePressed

    private void rCanakkaleMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCanakkaleMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Canakkale Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Canakkale");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rCanakkaleMousePressed

    private void rBalikesirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBalikesirMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Balikesir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Balikesir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
                TourInfoFrame.setVisible(true);
            }

        }
    }//GEN-LAST:event_rBalikesirMousePressed

    private void rIzmirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIzmirMousePressed
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Izmir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Izmir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
                TourInfoFrame.setVisible(true);
            }

        }
    }//GEN-LAST:event_rIzmirMousePressed

    private void rManisaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rManisaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Manisa Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Manisa");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rManisaMousePressed

    private void rAydinMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAydinMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Aydin Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Aydin");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAydinMousePressed

    private void rMuglaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMuglaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Mugla Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Mugla");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rMuglaMousePressed

    private void rDenizliMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDenizliMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Denizli Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Denizli");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rDenizliMousePressed

    private void rBurdurMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBurdurMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Burdur Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Burdur");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBurdurMousePressed

    private void rIspartaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIspartaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Isparta Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Isparta");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rIspartaMousePressed

    private void rAfyonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAfyonMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Afyon Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Afyon");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAfyonMousePressed

    private void rAfyonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAfyonMouseEntered
        // TODO add your handling code here:
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/afyon1.png"));
        rAfyon.setIcon(img);
        bilgi.setText("AFYONKARAHISAR");
    }//GEN-LAST:event_rAfyonMouseEntered

    private void rAfyonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAfyonMouseExited
        // TODO add your handling code here:
        ImageIcon img = new ImageIcon(getClass().getResource("resimler/afyon.png"));
        rAfyon.setIcon(img);
        bilgi.setText("");
    }//GEN-LAST:event_rAfyonMouseExited

    private void rKutahyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKutahyaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kutahya Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kutahya");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKutahyaMousePressed

    private void rUsakMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rUsakMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Usak Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Usak");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rUsakMousePressed

    private void rBursaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBursaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bursa Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bursa");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBursaMousePressed

    private void rEskisehirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rEskisehirMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Eskisehir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Eskisehir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rEskisehirMousePressed

    private void rBilecikMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBilecikMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bilecik Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bilecik");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBilecikMousePressed

    private void rBoluMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBoluMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bolu Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bolu");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBoluMousePressed

    private void rDuzceMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDuzceMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Duzce Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Duzce");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rDuzceMousePressed

    private void rKocaeliMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKocaeliMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kocaeli Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kocaeli");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKocaeliMousePressed

    private void rIstanbulMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIstanbulMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Istanbul Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Istanbul");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rIstanbulMousePressed

    private void rSakaryaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSakaryaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Sakarya Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Sakarya");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rSakaryaMousePressed

    private void rKaramanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKaramanMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Karaman Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Karaman");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKaramanMousePressed

    private void rMersinMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMersinMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Mersin Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Mersin");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rMersinMousePressed

    private void rAksarayMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAksarayMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Aksaray Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Aksaray");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAksarayMousePressed

    private void rZonguldakMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rZonguldakMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Zonguldak Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Zonguldak");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rZonguldakMousePressed

    private void rKarabukMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKarabukMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Karabuk Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Karabuk");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKarabukMousePressed

    private void rBartinMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBartinMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bartin Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bartin");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBartinMousePressed

    private void rCankiriMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCankiriMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Cankiri Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Cankiri");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rCankiriMousePressed

    private void rKirikkaleMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirikkaleMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kirikkale Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kirikkale");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKirikkaleMousePressed

    private void rKirsehirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKirsehirMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kirsehir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kirsehir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKirsehirMousePressed

    private void rNevsehirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rNevsehirMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Nevsehir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Nevsehir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rNevsehirMousePressed


    private void rNigdeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rNigdeMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Nigde Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Nigde");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rNigdeMousePressed

    private void rAdanaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAdanaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Adana Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Adana");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAdanaMousePressed

    private void rKayseriMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKayseriMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kayseri Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kayseri");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKayseriMousePressed

    private void rCorumMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rCorumMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Corum Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Corum");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rCorumMousePressed

    private void rKastamonuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKastamonuMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kastamonu Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kastamonu");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKastamonuMousePressed

    private void rTunceliMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTunceliMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Tunceli Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Tunceli");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }
        }
    }//GEN-LAST:event_rTunceliMousePressed

    private void rSinopMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSinopMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Sinop Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Sinop");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rSinopMousePressed

    private void rSamsunMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSamsunMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Samsun Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Samsun");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rSamsunMousePressed

    private void rSamsunMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSamsunMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_rSamsunMouseReleased

    private void rAmasyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAmasyaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Amasya Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Amasya");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAmasyaMousePressed

    private void rTokatMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTokatMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Tokat Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Tokat");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rTokatMousePressed

    private void rSivasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSivasMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Sivas Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Sivas");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rSivasMousePressed

    private void rMalatyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMalatyaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Malatya Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Malatya");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rMalatyaMousePressed

    private void rAdiyamanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAdiyamanMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Adiyaman Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Adiyaman");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAdiyamanMousePressed

    private void rUrfaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rUrfaMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("SanliUrfa Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("SanliUrfa");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rUrfaMousePressed

    private void rGiresunMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rGiresunMousePressed
        // TODO add your handling code here:
        area.setText("");
        // TourInfoFrame.setVisible(true);
        sepetpanel.setVisible(false);
        sadecesehir.setText("Giresun Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Giresun");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rGiresunMousePressed

    private void rErzincanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rErzincanMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Erzincan Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Erzincan");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rErzincanMousePressed

    private void rElazigMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rElazigMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Elazig Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Elazig");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rElazigMousePressed

    private void rDiyarbakirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rDiyarbakirMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Diyarbakir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Diyarbakir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rDiyarbakirMousePressed

    private void rMardinMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMardinMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Mardin Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Mardin");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rMardinMousePressed

    private void rGumushaneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rGumushaneMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Gumushane Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Gumushane");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rGumushaneMousePressed

    private void rTrabzonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rTrabzonMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Trabzon Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Trabzon");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rTrabzonMousePressed

    private void rRizeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rRizeMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Rize Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Rize");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rRizeMousePressed

    private void rErzurumMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rErzurumMousePressed
        // TODO add your handling code here:
        area.setText("");
        sepetpanel.setVisible(false);
        sadecesehir.setText("Erzurum Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Erzurum");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rErzurumMousePressed

    private void rBingolMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBingolMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bingol Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bingol");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBingolMousePressed

    private void rArtvinMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rArtvinMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Artvin Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Artvin");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rArtvinMousePressed

    private void rArdahanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rArdahanMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Ardahan Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Ardahan");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rArdahanMousePressed

    private void rKarsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKarsMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kars Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kars");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKarsMousePressed

    private void rIgdirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rIgdirMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Igdir Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Igdir");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rIgdirMousePressed

    private void rAgriMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAgriMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Agri Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Agri");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAgriMousePressed

    private void rMusMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMusMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Mus Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Mus");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rMusMousePressed

    private void rBitlisMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBitlisMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bitlis Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bitlis");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBitlisMousePressed

    private void rVanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rVanMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Van Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Van");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rVanMousePressed

    private void rSiirtMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSiirtMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Siirt Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Siirt");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rSiirtMousePressed

    private void rHakkariMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rHakkariMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Hakkari Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Hakkari");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rHakkariMousePressed

    private void rSirnakMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSirnakMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Sirnak Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Sirnak");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rSirnakMousePressed

    private void rBatmanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBatmanMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Batman Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Batman");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBatmanMousePressed

    private void rKilisMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rKilisMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kilis Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kilis");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rKilisMousePressed

    private void rAntepMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAntepMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Antep Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Antep");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAntepMousePressed

    private void rOsmaniyeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOsmaniyeMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Osmaniye Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Osmaniye");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rOsmaniyeMousePressed

    private void rMarasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rMarasMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Kahramanmaras Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Kahramanmaras");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rMarasMousePressed

    private void rBayburtMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rBayburtMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Bayburt Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Bayburt");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rBayburtMousePressed

    private void signinPasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_signinPasswordKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            boolean kontrol = false;
            String username;
            String password;
            int control = 0;
            try {
                username = signInusername.getText();
                password = signinPassword.getText();
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Some blank is empty!!", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (memberLists.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Empty List!", "Error", JOptionPane.WARNING_MESSAGE);
                } else {
                    for (int i = 0; i < memberLists.size(); i++) {
                        if (memberLists.get(i).check(username, password)) {
                            signs.setVisible(false);
                            signin.setVisible(false);
                            //btSignIn.setVisible(false);
                            //btSignUp.setVisible(false);
                            welcome.setText("hello " + memberLists.get(i).getName() + " " + memberLists.get(i).getSurname());
                            btSignIn.setVisible(false);
                            btSignUp.setVisible(false);
                            control = 1;
                            kontrol = true;
                            sepetekle.setVisible(true);
                            sepet.setVisible(true);
//                            hemenal.setVisible(true);
                            break;
                        }
                    }
                    if (control == 0) {
                        // System.out.println("username "+username +"but listed");

                        sepetekle.setVisible(false);
                        sepet.setVisible(false);
                        // hemenal.setVisible(false);
                        JOptionPane.showMessageDialog(null, "wrong username or password!", "Error", JOptionPane.ERROR_MESSAGE);
                        welcome.setText("");
                    }

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Try again!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_signinPasswordKeyPressed

    private void rHatayMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rHatayMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Hatay Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Hatay");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rHatayMousePressed

    private void rAnkaraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rAnkaraMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Ankara");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Ankara");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rAnkaraMousePressed

    private void rOrduMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOrduMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_rOrduMouseReleased

    private void rOrduMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rOrduMousePressed
        // TODO add your handling code here:
        area.setText("");

        sepetpanel.setVisible(false);
        sadecesehir.setText("Ordu Tour");
        sehirpanel.setVisible(true);
        ArrayList<Tour> find = admin.contentWith("Ordu");
        int size = find.size();
        if (find.isEmpty()) {
            TourInfoFrame.setVisible(false);
            JOptionPane.showMessageDialog(null, "Tour was not founded", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            TourInfoFrame.setVisible(true);
            for (int i = 0; i < size; i++) {
                area.append(find.get(i).toString() + "\n\n");
                String a = find.get(i).getImageURL();
                ImageIcon s = new ImageIcon(a);
                image.setIcon(s);
            }

        }
    }//GEN-LAST:event_rOrduMousePressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                new Turkey().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFrame BasketFrame;
    private javax.swing.JFrame TourInfoFrame;
    private javax.swing.JPanel Turkey;
    private javax.swing.JButton adminLogIn;
    private javax.swing.JFrame adminLogin;
    private javax.swing.JTextArea area;
    private javax.swing.JTable baskettable;
    private javax.swing.JLabel bilgi;
    private javax.swing.JTextArea bittimgozunaydin;
    private javax.swing.JButton btAdmin;
    private javax.swing.JButton btSignIn;
    private javax.swing.JButton btSignUp;
    private javax.swing.JPanel buypanel;
    private javax.swing.JRadioButton campingTourSearch;
    private javax.swing.JTextField cardname;
    private javax.swing.JTextField cardnumber;
    private javax.swing.JTextField cardsurname;
    private javax.swing.JRadioButton culturalTourSearch;
    private javax.swing.JTextField cvc;
    private javax.swing.JButton fSignIn;
    private javax.swing.JButton fSignUp;
    private javax.swing.JTextArea findTourInfo;
    private javax.swing.JLabel image;
    private javax.swing.JLabel infoMessage;
    private javax.swing.JScrollPane infomessage;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSpinner maxValue;
    private javax.swing.JSpinner minValue;
    private javax.swing.JRadioButton mixedTourSearch;
    private javax.swing.JTextField month;
    private javax.swing.JLabel naber;
    private javax.swing.JRadioButton naturalTourSearch;
    private javax.swing.JLabel otekiCanakkale;
    private javax.swing.JPasswordField passwordAdmin;
    private javax.swing.JLabel rAdana;
    private javax.swing.JLabel rAdiyaman;
    private javax.swing.JLabel rAfyon;
    private javax.swing.JLabel rAgri;
    private javax.swing.JLabel rAksaray;
    private javax.swing.JLabel rAmasya;
    private javax.swing.JLabel rAnkara;
    private javax.swing.JLabel rAntalya;
    private javax.swing.JLabel rAntep;
    private javax.swing.JLabel rArdahan;
    private javax.swing.JLabel rArtvin;
    private javax.swing.JLabel rAydin;
    private javax.swing.JLabel rBalikesir;
    private javax.swing.JLabel rBartin;
    private javax.swing.JLabel rBatman;
    private javax.swing.JLabel rBayburt;
    private javax.swing.JLabel rBilecik;
    private javax.swing.JLabel rBingol;
    private javax.swing.JLabel rBitlis;
    private javax.swing.JLabel rBolu;
    private javax.swing.JLabel rBurdur;
    private javax.swing.JLabel rBursa;
    private javax.swing.JLabel rCanakkale;
    private javax.swing.JLabel rCankiri;
    private javax.swing.JLabel rCorum;
    private javax.swing.JLabel rDenizli;
    private javax.swing.JLabel rDiyarbakir;
    private javax.swing.JLabel rDuzce;
    private javax.swing.JLabel rEdirne;
    private javax.swing.JLabel rElazig;
    private javax.swing.JLabel rErzincan;
    private javax.swing.JLabel rErzurum;
    private javax.swing.JLabel rEskisehir;
    private javax.swing.JLabel rGiresun;
    private javax.swing.JLabel rGumushane;
    private javax.swing.JLabel rHakkari;
    private javax.swing.JLabel rHatay;
    private javax.swing.JLabel rIgdir;
    private javax.swing.JLabel rIsparta;
    private javax.swing.JLabel rIstanbul;
    private javax.swing.JLabel rIzmir;
    private javax.swing.JLabel rKarabuk;
    private javax.swing.JLabel rKaraman;
    private javax.swing.JLabel rKars;
    private javax.swing.JLabel rKastamonu;
    private javax.swing.JLabel rKayseri;
    private javax.swing.JLabel rKilis;
    private javax.swing.JLabel rKirikkale;
    private javax.swing.JLabel rKirklareli;
    private javax.swing.JLabel rKirsehir;
    private javax.swing.JLabel rKocaeli;
    private javax.swing.JLabel rKonya;
    private javax.swing.JLabel rKutahya;
    private javax.swing.JLabel rMalatya;
    private javax.swing.JLabel rManisa;
    private javax.swing.JLabel rMaras;
    private javax.swing.JLabel rMardin;
    private javax.swing.JLabel rMersin;
    private javax.swing.JLabel rMugla;
    private javax.swing.JLabel rMus;
    private javax.swing.JLabel rNevsehir;
    private javax.swing.JLabel rNigde;
    private javax.swing.JLabel rOrdu;
    private javax.swing.JLabel rOsmaniye;
    private javax.swing.JLabel rRize;
    private javax.swing.JLabel rSakarya;
    private javax.swing.JLabel rSamsun;
    private javax.swing.JLabel rSiirt;
    private javax.swing.JLabel rSinop;
    private javax.swing.JLabel rSirnak;
    private javax.swing.JLabel rSivas;
    private javax.swing.JLabel rTekirdag;
    private javax.swing.JLabel rTokat;
    private javax.swing.JLabel rTrabzon;
    private javax.swing.JLabel rTunceli;
    private javax.swing.JLabel rUrfa;
    private javax.swing.JLabel rUsak;
    private javax.swing.JLabel rVan;
    private javax.swing.JLabel rYozgat;
    private javax.swing.JLabel rZonguldak;
    private javax.swing.JSpinner s1;
    private javax.swing.JSpinner s10;
    private javax.swing.JSpinner s2;
    private javax.swing.JSpinner s3;
    private javax.swing.JSpinner s4;
    private javax.swing.JSpinner s5;
    private javax.swing.JSpinner s6;
    private javax.swing.JSpinner s7;
    private javax.swing.JSpinner s8;
    private javax.swing.JSpinner s9;
    private javax.swing.JTextField sadecesehir;
    private javax.swing.JButton satınal;
    private javax.swing.JButton satınal1;
    private javax.swing.JButton searchButton;
    private javax.swing.JFrame searchFrame;
    private javax.swing.JPanel sehirpanel;
    private javax.swing.JButton sepet;
    private javax.swing.JButton sepetekle;
    private javax.swing.JPanel sepetpanel;
    private javax.swing.JTextField signInusername;
    private javax.swing.JPanel signin;
    private javax.swing.JPasswordField signinPassword;
    private javax.swing.JFrame signs;
    private javax.swing.JPanel signup;
    private javax.swing.JTextField signupEmail;
    private javax.swing.JTextField signupName;
    private javax.swing.JPasswordField signupPassword;
    private javax.swing.JTextField signupTelephone;
    private javax.swing.JTextField signupUsername;
    private javax.swing.JTextField signupsurname;
    private javax.swing.JRadioButton summerTourSearch;
    private javax.swing.ButtonGroup types;
    private javax.swing.JTextField usernameAdmin;
    private javax.swing.JLabel welcome;
    private javax.swing.JRadioButton winterTourSearch;
    private javax.swing.JTextField year;
    // End of variables declaration//GEN-END:variables
}
