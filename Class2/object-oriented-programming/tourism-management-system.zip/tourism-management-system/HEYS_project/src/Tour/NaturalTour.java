package Tour;

public class NaturalTour extends Tour {

    protected String bungalovName;
    protected String region;
    protected String place_to_visit;

    public NaturalTour() {

    }

    public NaturalTour(String bungalovName, String region, String place_to_visit, String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        super(tourName, howManyDay, capacity, price, first_day, first_month, first_year, last_day, last_month, last_year, imageURL);
        this.bungalovName = bungalovName;
        this.region = region;
        this.place_to_visit = place_to_visit;
    }

    public String getBungalovName() {
        return bungalovName;
    }

    public String getRegion() {
        return region;
    }

    public String getPlace_to_visit() {
        return place_to_visit;
    }

    public void setBungalovName(String bungalovName) {
        this.bungalovName = bungalovName;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setPlace_to_visit(String place_to_visit) {
        this.place_to_visit = place_to_visit;
    }

    @Override
    public String toString() {
        return "Natural Tour\n" + super.toString() + "\nBungalov Name: " + bungalovName
                + "\nRegion=" + region + "\nPlace to Visit" + place_to_visit;
    }

    @Override
    public String informationMessage() {
        return "There can be delays due to weather\nThese tours start from Istanbul.";
    }

}
