package Tour;

public class CulturalTour extends Tour {

    protected String hotelName;
    protected String cityName;

    protected String place_to_visit;

    public CulturalTour() {

    }

    public CulturalTour(String hotelName, String cityName, String place_to_visit, String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        super(tourName, howManyDay, capacity, price, first_day, first_month, first_year, last_day, last_month, last_year, imageURL);
        this.hotelName = hotelName;
        this.cityName = cityName;
        this.place_to_visit = place_to_visit;
    }

    public String getHotelName() {
        return hotelName;
    }

    public String getCityName() {
        return cityName;
    }

    public String getPlace_to_visit() {
        return place_to_visit;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public void setPlace_to_visit(String place_to_visit) {
        this.place_to_visit = place_to_visit;
    }

    @Override
    public String toString() {
        return "Cultural Tour\n" + super.toString() + "\nHotel Name: " + hotelName
                + "\nCity Name: " + cityName + "\nPlace to Visit: " + place_to_visit;
    }

    @Override
    public String informationMessage() {
        return "All museum tickets are included in the invoice\nThese tours start from Ankara.";
    }

}
