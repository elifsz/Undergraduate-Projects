package Tour;

public class MixedTour extends Tour {

    protected String cityName;
    protected String place_to_visit;

    public MixedTour() {

    }

    public MixedTour(String cityName, String place_to_visit, String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        super(tourName, howManyDay, capacity, price, first_day, first_month, first_year, last_day, last_month, last_year, imageURL);
        this.cityName = cityName;
        this.place_to_visit = place_to_visit;
    }

    public String getCityName() {
        return cityName;
    }

    public String getPlace_to_visit() {
        return place_to_visit;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public void setPlace_to_visit(String place_to_visit) {
        this.place_to_visit = place_to_visit;
    }

    @Override
    public String informationMessage() {
        return "This tour is a daily tour.\nThese tours stars from city center.";
    }

    @Override
    public String toString() {
        return "Mixed Tour\n" + super.toString() + "\nCity Name: " + cityName
                + "\nPlace to Visit" + place_to_visit;
    }

    public String position(String startpoint) {
        return "This tour starts from " + startpoint;
    }

}
