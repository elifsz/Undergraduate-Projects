package Tour;

public class WinterTour extends Tour {

    protected String skiResortName;
    protected String hotelName;

    public WinterTour() {

    }

    public WinterTour(String skiResortName, String hotelName, String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        super(tourName, howManyDay, capacity, price, first_day, first_month, first_year, last_day, last_month, last_year, imageURL);
        this.skiResortName = skiResortName;
        this.hotelName = hotelName;
    }

    public String getSkiResortName() {
        return skiResortName;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setSkiResortName(String skiResortName) {
        this.skiResortName = skiResortName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    @Override
    public String informationMessage() {
        return "There is only service in winter\nThese tours start from city center.";
    }

    @Override
    public String toString() {
        return "Winter Tour\n" + super.toString() + "\nSki Resort Name: " + skiResortName
                + "\nHotel Name: " + hotelName;
    }

}
