package Tour;

import java.util.ArrayList;

public abstract class Tour {

    protected String tourName;
    protected String howManyDay;
    protected int capacity;
    protected double price;
    protected static int totalCustomer = 0;
    protected static int totalMoney = 0;
    protected int first_day;
    protected int first_month;
    protected int first_year;
    protected int last_day;
    protected int last_month;
    protected int last_year;
    protected String imageURL;
    protected String tourType;

    public Tour() {

    }

    public Tour(String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        this.tourName = tourName;
        this.howManyDay = howManyDay;
        this.capacity = capacity;
        this.price = price;
        this.first_day = first_day;
        this.first_month = first_month;
        this.first_year = first_year;
        this.last_day = last_day;
        this.last_month = last_month;
        this.last_year = last_year;
        this.imageURL = imageURL;
    }

    public ArrayList<String> placeToVisit() {
        return null;
    }

    public Tour(String tourType) {
        this.tourType = tourType;
    }

    public static int getTotalMoney() {
        return totalMoney;
    }

    public String getTourType() {
        return tourType;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public String getHowManyDay() {
        return howManyDay;
    }

    public int getCapacity() {
        return capacity;
    }

    public double getPrice() {
        return price;
    }

    public static int getTotalCustomer() {
        return totalCustomer;
    }

    public int getFirst_day() {
        return first_day;
    }

    public int getFirst_month() {
        return first_month;
    }

    public int getFirst_year() {
        return first_year;
    }

    public int getLast_day() {
        return last_day;
    }

    public int getLast_month() {
        return last_month;
    }

    public int getLast_year() {
        return last_year;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setHowManyDay(String howManyDay) {
        this.howManyDay = howManyDay;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public static void setTotalMoney(int totalMoney) {
        Tour.totalMoney = totalMoney;
    }

    public static void setTotalCustomer(int totalCustomer) {
        Tour.totalCustomer = totalCustomer;
    }

    public void setFirst_day(int first_day) {
        this.first_day = first_day;
    }

    public void setFirst_month(int first_month) {
        this.first_month = first_month;
    }

    public void setFirst_year(int first_year) {
        this.first_year = first_year;
    }

    public void setLast_day(int last_day) {
        this.last_day = last_day;
    }

    public void setLast_month(int last_month) {
        this.last_month = last_month;
    }

    public void setLast_year(int last_year) {
        this.last_year = last_year;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public abstract String informationMessage();

    @Override
    public String toString() {
        return "tourName: " + tourName
                + "\nhowManyDay: " + howManyDay
                + "\ncapacity: " + capacity
                + "\nprice: " + price
                + "\nStart date: " + first_day + "-" + first_month + "-" + first_year
                + "\nFinish date: " + last_day + "-" + last_month + "-" + last_year;
    }

}
