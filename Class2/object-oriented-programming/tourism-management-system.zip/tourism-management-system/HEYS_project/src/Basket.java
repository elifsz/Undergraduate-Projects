
public class Basket {

    public String TourName;
    public int howmany;
    public double price;
    public static double total_price;
    
    public Basket(String TourName, double price) {
        this.TourName = TourName;
        this.price = price;
    }

    public String getTourName() {
        return TourName;
    }

    public int getHowmany() {
        return howmany;
    }

    public double getPrice() {
        return price;
    }

    public static double getTotal_price() {
        return total_price;
    }

    public void setTourName(String TourName) {
        this.TourName = TourName;
    }

    public void setHowmany(int howmany) {
        this.howmany = howmany;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    @Override
    public String toString() {
        return  "\nTour Name: " + TourName + "\nNumber of people: " + howmany + "\nTour price: " + price;
    }
    

}
